#ifndef LICENSE_H
#define LICENSE_H

#include <QStringList>

class License
{
public:
    License();

    bool verify();
    bool checkMACAddress();
    QStringList getMACAddressList();
    QString hash(const QString& data);
};

#endif // LICENSE_H
