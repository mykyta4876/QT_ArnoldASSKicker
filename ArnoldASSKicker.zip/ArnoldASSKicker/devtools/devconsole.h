#ifndef DEVCONSOLE_H
#define DEVCONSOLE_H

#include <QJsonDocument>
#include <QLineEdit>
#include <QPushButton>
#include <QShortcut>
#include <QTextEdit>

class DevConsole
{
public:
    class Events {
    public:
        virtual ~Events() {}

        virtual void change() = 0;
    };

    DevConsole(QWidget* parent);

    QWidget* widget();
    Events* events();

    QString json();
    QJsonValue value(QString path);

    int numKeys(QString path = QString());
    QString key(int index);
    QString key(QString path, int index);
    QString path(QString path, int index);

    void setEvents(Events* events);
    void setValue(QString path, QJsonValue& value);
    void save(QString json);
    void render();
    void update();
    void goToPath(QString path);

private:
    QWidget* _widget;
    Events* _events;

    QShortcut* _shortcut;
    QLineEdit* _path;
    QTextEdit* _editor;
    QPushButton* _goToPath;
    QPushButton* _save;
    QJsonDocument _json;

    QString _currentPath;

    void performLayout();
    void setupStyleSheet();
};

#endif // DEVCONSOLE_H
