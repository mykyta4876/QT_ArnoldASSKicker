#include "devconsole.h"

#include <QJsonArray>
#include <QJsonObject>

DevConsole::DevConsole(QWidget* parent) :
    _widget(new QWidget(parent)),
    _events(nullptr),
    _shortcut(new QShortcut(parent)),
    _path(new QLineEdit(_widget)),
    _editor(new QTextEdit(_widget)),
    _goToPath(new QPushButton(_widget)),
    _save(new QPushButton(_widget))
{
    _widget->setObjectName("devConsole");
    _widget->setWindowFlags(Qt::Window);
    _widget->setWindowTitle(parent->windowTitle() + " - Developer Console");
    _widget->resize(640, 480);
    _widget->hide();

    _shortcut->setKey(QKeySequence("Ctrl+Shift+J"));
    _shortcut->setAutoRepeat(false);

    _path->setObjectName("devConsole_path");
    _editor->setObjectName("devConsole_editor");

    _goToPath->setObjectName("devConsole_goToPath");
    _goToPath->setText("Go");
    _goToPath->setCursor(Qt::PointingHandCursor);

    _save->setObjectName("devConsole_save");
    _save->setText("Save");
    _save->setCursor(Qt::PointingHandCursor);

    QObject::connect(_shortcut, &QShortcut::activated, _shortcut, [&]() {
        _widget->showNormal();
    });

    QObject::connect(_goToPath, &QPushButton::clicked, _goToPath, [&]() {
        goToPath(_path->text());
    });

    QObject::connect(_save, &QPushButton::clicked, _save, [&]() {
        update();
    });
}

QWidget* DevConsole::widget()
{
    return _widget;
}

DevConsole::Events* DevConsole::events()
{
    return _events;
}

QString DevConsole::json()
{
    return _json.toJson();
}

QJsonValue DevConsole::value(QString path)
{
    QStringList keys = path.split('.');
    if (keys.isEmpty()) return QJsonValue();

    QJsonValue value = _json[keys[0]];

    for (QString& key : keys.sliced(1)) {
        if (value.isObject()) {
            value = value[key];

        } else if (value.isArray()) {
            value = value[key.toInt()];

        } else break;
    }

    return value;
}

int DevConsole::numKeys(QString path)
{
    QJsonValue value = this->value(path);
    if (!value.isObject()) return 0;

    return value.toObject().size();
}

QString DevConsole::key(int index)
{
    if (!_json.isObject()) return QString();

    return _json.object().keys().value(index);
}

QString DevConsole::key(QString path, int index)
{
    QJsonValue value = this->value(path);
    if (!value.isObject()) return QString();

    QJsonObject object = value.toObject();
    return object.keys().value(index);
}

QString DevConsole::path(QString path, int index)
{
    return path + key(path, index);
}

void DevConsole::setEvents(Events* events)
{
    _events = events;
}

QJsonValue modify(QJsonValue json, QStringList path, QJsonValue& value)
{
    if (path.isEmpty()) return value;

    if (json.isObject()) {
        QJsonObject object = json.toObject();
        QString key = path[0];

        if (path.size() == 1) {
            object[key] = value;
        } else {
            QJsonValue jsonChild = object[key];
            object[key] = modify(jsonChild, path.sliced(1), value);
        }

        return object;
    }

    if (json.isArray()) {
        QJsonArray array = json.toArray();
        int i = path[0].toInt();

        if (path.size() == 1) {
            array[i] = value;
        } else {
            QJsonValue jsonChild = array[i];
            array[i] = modify(jsonChild, path.sliced(1), value);
        }

        return array;
    }

    return json;
}

void DevConsole::setValue(QString path, QJsonValue& value_)
{
    QStringList keys = path.split('.');
    if (keys.isEmpty()) return;

    if (keys.size() == 1) {
        QJsonObject object = _json.object();
        object[keys[0]] = value_;
        _json.setObject(object);
        return;
    }

    QJsonObject object = _json.object();
    QJsonValue value = object[keys[0]];
    QJsonValue newValue = modify(value, keys.sliced(1), value_);

    object[keys[0]] = newValue;
    _json.setObject(object);
}

void DevConsole::save(QString json)
{
    if (_currentPath.isEmpty()) {
        _json = QJsonDocument::fromJson(json.toLatin1());

    } else {
        QJsonDocument doc = QJsonDocument::fromJson(json.toLatin1());
        if (doc.isObject()) {
            QJsonValue value(doc.object());
            setValue(_currentPath, value);

        } else if (doc.isArray()) {
            QJsonValue value(doc.array());
            setValue(_currentPath, value);
        }
    }
}

void DevConsole::render()
{
    performLayout();

    if (_currentPath.isEmpty()) {
        _editor->setText(json());

    } else {
        QJsonDocument doc;
        QJsonValue val = this->value(_currentPath);
        if (val.isObject()) {
            doc.setObject(val.toObject());

        } else if (val.isArray()) {
            doc.setArray(val.toArray());

        } else {
            doc = _json;
        }
        _editor->setText(doc.toJson());
    }

    setupStyleSheet();
}

void DevConsole::goToPath(QString path)
{
    _currentPath = path;
    render();
}

void DevConsole::update()
{
    save(_editor->toPlainText());
    render();

    events()->change();
}

void DevConsole::performLayout()
{
    QRect path;
    QRect goToPath;
    QRect editor;
    QRect save;

    int width = _widget->width();
    int height = _widget->height();

    path.setWidth(width - width / 10);
    path.setHeight(height / 10);

    goToPath.setWidth(width - path.width());
    goToPath.setHeight(path.height());
    goToPath.moveTo(path.width(), 0);

    save.setWidth(width);
    save.setHeight(height / 10);
    save.moveTo(0, height - save.height());

    editor.moveTo(0, path.height());
    editor.setWidth(width);
    editor.setHeight(save.y() - editor.y());

    _path->setGeometry(path);
    _editor->setGeometry(editor);
    _goToPath->setGeometry(goToPath);
    _save->setGeometry(save);
}

void DevConsole::setupStyleSheet()
{

}
