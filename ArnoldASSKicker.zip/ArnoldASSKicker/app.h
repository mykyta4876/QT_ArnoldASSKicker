#ifndef APP_H
#define APP_H

#include "kickassapp.h"

#include "devtools/devconsole.h"
#include "filesequence/filesequence.h"
#include "license.h"
#include "settings/settings.h"
#include "ui/ui.h"

#include <QApplication>

class App
{
public:
    App(int argc, char* argv[]);
    ~App();

    int run();
    void update();

private:
    QApplication _app;
    UI _ui;
    Settings _settings;
    FileSequence _fileSequence;
    License _license;
    DevConsole _devConsole;
    KickAssApp* _kApp;

    void buildSettingsForm();

    struct DevConsoleEvents : public DevConsole::Events {
        App& _ref;
        DevConsoleEvents(App& ref) : _ref(ref) {}
        void change() { _ref.devConsoleChange(); }
    } _devConsoleEvents;

    void devConsoleChange();
};

#endif // APP_H
