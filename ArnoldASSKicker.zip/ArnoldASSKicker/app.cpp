#include "app.h"
#include <QFile>
#include <QTextStream>
#include <QStandardPaths>
#include <QDir>

//------------------------------
//Util

bool writeFile(QString filePath, const QString& fileContents)
{
    if (filePath.isEmpty()) {
        QString desktopPath = QStandardPaths::writableLocation(
            QStandardPaths::DesktopLocation);
        filePath = QDir(desktopPath).filePath("output.txt");
    }

    QFile file(filePath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QString err = "Couldn't open file: " + filePath;
        qWarning() << err;
        return false;
    }

    QTextStream out(&file);
    out << fileContents;
    file.close();

    return true;
}

QString widgetTreeDebugString(QWidget* rootWidget, int depth = 0)
{
    if (!rootWidget) return "";

    QString name = rootWidget->objectName();
    if (name.startsWith("qt")) return "";
    if (name.isEmpty()) {
        name = "(no name)";
    }

    QString indent(depth * 2, ' ');
    QString debugInfo = QString("%1%2: (%3, %4) %5 x %6\n").arg(
        indent,
        name,
        QString::number(rootWidget->x()),
        QString::number(rootWidget->y()),
        QString::number(rootWidget->width()),
        QString::number(rootWidget->height()));

    const QList<QWidget*> children = rootWidget->findChildren<QWidget*>(
        Qt::FindDirectChildrenOnly);
    for (QWidget* child : children) {
        debugInfo += widgetTreeDebugString(child, depth + 1);
    }

    return debugInfo;
}

//------------------------------

App::App(int argc, char* argv[]) :
    _app(argc, argv),
    _devConsole(_ui.widget()),
    _devConsoleEvents(*this)
{
    QCoreApplication::setOrganizationName(_settings.organizationName());
    QCoreApplication::setOrganizationDomain(_settings.organizationDomain());
    QCoreApplication::setApplicationName(_settings.applicationName());
    QCoreApplication::setApplicationVersion(_settings.version());

    buildSettingsForm();

    _ui.window().setTitle(_settings.windowTitle());

    _kApp = new KickAssApp(
        _ui,
        _settings,
        _fileSequence);

    QFile loadFile(":/config/ui.json");
    QString uiJson = "{}";

    if (loadFile.open(QIODevice::ReadOnly)) {
        QByteArray fileData = loadFile.readAll();
        uiJson = QString::fromLatin1(fileData);

        QJsonDocument doc = QJsonDocument::fromJson(fileData);
        QJsonObject layoutConfig = doc.object();
        _ui.mainPage().loadLayout(layoutConfig);

    } else {
        qWarning("Couldn't open file.");
    }

    _devConsole.setEvents(&_devConsoleEvents);
    _devConsole.save("{"
        "\"resize\": {"
            "\"perform\": false,"
            "\"target\": \"contents\","
            "\"width\": 1000,"
            "\"height\": 500"
        "},"
        "\"contentSizeFixed\": false,"
        "\"printWidgetTree\": false,"
        "\"printLayoutTree\": false,"
        "\"printSettings\": false,"
        "\"printSettingsConfig\": false,"
        "\"printPath\": \"\","
        "\"performUIUpdate\": false,"
        "\"ui\": " + uiJson +
    "}");
}

App::~App()
{
    if (_kApp != nullptr) {
        delete _kApp;
    }
}

int App::run()
{
    if (!_license.verify()) {
        QString title = _settings.windowTitle();
        QString msg = "Unable to verify license";
        QMessageBox::warning(_ui.widget(), title, msg);
        return 0;
    }

    update();
    return _app.exec();
}

void App::update()
{
    _ui.render();
    _devConsole.render();
}

//TODO: where to move this?
void App::buildSettingsForm()
{
    SettingsForm& form = _ui.mainPage().settings();

    int n = _settings.numGroups();
    for (int i = 0; i < n; i++) {
        SettingsGroup* group = _settings.group(i);
        form.addGroup(group->widgetName(), group->title());

        GroupForm* groupForm = form.group(i);
        if (groupForm == nullptr) continue;

        int n2 = group->numCommands();
        for (int i = 0; i < n2; i++) {
            SettingsCommand* command = group->command(i);
            groupForm->addCommand(
                command->widgetName(),
                command->label() + (group->labelColon() ? ":" : ""),
                command->statusTip());

            CommandField* field = groupForm->command(i);
            if (field == nullptr) continue;

            field->enable(command->enabled());

            int n3 = command->numParameters();
            for (int i = 0; i < n3; i++) {
                SettingsParameter* parameter = command->parameter(i);
                field->addParameter(
                    parameter->widgetName(),
                    parameter->type());

                ParameterInput* input = field->parameter(i);
                if (input == nullptr) continue;

                int n4 = parameter->numOptions();
                for (int i = 0; i < n4; i++) {
                    QString label = parameter->option(i).label;
                    input->addOption(label);
                }

                input->setValue(parameter->toString());
            }
        }
    }

    QString output = widgetTreeDebugString(_ui.widget());
    writeFile("", output);
}

void App::devConsoleChange()
{
    bool contentSizeFixed = _devConsole.value("contentSizeFixed").toBool();
    _ui.window().fixContentSize(contentSizeFixed);

    bool updateUI = _devConsole.value("performUIUpdate").toBool();
    if (updateUI) {
        QJsonObject config = _devConsole.value("ui").toObject();
        _ui.mainPage().loadLayout(config);
    }

    bool resize = _devConsole.value("resize.perform").toBool();
    if (resize) {
        QString target = _devConsole.value("resize.target").toString();
        int width = _devConsole.value("resize.width").toInt();
        int height = _devConsole.value("resize.height").toInt();

        if (target == "auto") {
            _ui.window().autoSize();
        }
        if (target == "window") {
            _ui.window().resize(width, height);
        }
        if (target == "viewport") {
            _ui.window().resizeViewport(width, height);
        }
        if (target == "contents") {
            _ui.window().resizeContents(width, height);
        }
    }

    QString output;

    bool printWidgetTree = _devConsole.value("printWidgetTree").toBool();
    if (printWidgetTree) {
        output += widgetTreeDebugString(_ui/*.mainPage()*/.widget());
    }

    bool printLayoutTree = _devConsole.value("printLayoutTree").toBool();
    if (printLayoutTree) {
        output += _ui.mainPage().layoutDebugString();
    }

    bool printSettings = _devConsole.value("printSettings").toBool();
    if (printSettings) {
        output += _settings.toJsonString();
    }

    bool printSettingsConfig = _devConsole.value("printSettingsConfig").toBool();
    if (printSettingsConfig) {
        output += _settings.exportConfigString();
    }

    if (!output.isEmpty()) {
        QString path = _devConsole.value("printPath").toString();
        writeFile(path, output);
    }

    update();
}
