#include "settingsgroup.h"

#include <QJsonArray>
#include <QJsonObject>

SettingsGroup::SettingsGroup(Settings* settings, QJsonObject& config) :
    _settings(settings)
{
    loadConfig(config);
}

SettingsGroup::~SettingsGroup()
{
    for (const SettingsCommand* command : _commands) {
        delete command;
    }
}

SettingsCommand* SettingsGroup::command(int index)
{
    if (index < 0 || numCommands() <= index) return nullptr;

    return _commands[index];
}

void SettingsGroup::read()
{
    _settings->beginGroup(_name);

    for (SettingsCommand* command : _commands) {
        command->read();
    }

    _settings->endGroup();
}

void SettingsGroup::write()
{
    _settings->beginGroup(_name);

    for (SettingsCommand* command : _commands) {
        command->write();
    }

    _settings->endGroup();
}

void SettingsGroup::clear()
{
    _settings->remove(_name);
}

void SettingsGroup::readFromUI(QWidget* ui)
{
    for (SettingsCommand* command : _commands) {
        command->readFromUI(ui);
    }
}

void SettingsGroup::writeToUI(QWidget* ui)
{
    for (SettingsCommand* command : _commands) {
        command->writeToUI(ui);
    }
}

void SettingsGroup::loadConfig(QJsonObject& config)
{
    _name = config["settingGroupName"].toString();
    _widgetName = config["widgetName"].toString();
    _title = config["title"].toString();
    _labelColon = config["labelColon"].toBool();

    _commands.clear();

    QJsonArray commands = config["commands"].toArray();
    for (int i = 0; i < commands.size(); i++) {
        QJsonObject config = commands[i].toObject();
        SettingsCommand* command = new SettingsCommand(_settings, config);
        _commands.append(command);
    }
}

QString SettingsGroup::toArgString()
{
    QStringList args;
    for (SettingsCommand* command : _commands) {
        QString str = command->toArgString();
        if (!str.isEmpty()) {
            args.append(str);
        }
    }
    return args.join(' ');
}

QJsonObject SettingsGroup::toJson()
{
    QJsonObject json;

    for (SettingsCommand* command : _commands) {
        json[command->name()] = command->toJson();
    }

    return json;
}

QJsonObject SettingsGroup::exportConfig()
{
    QJsonObject config;
    QJsonArray commands;

    for (SettingsCommand* command : _commands) {
        commands.append(command->exportConfig());
    }

    config["settingGroupName"] = _name;
    config["widgetName"] = _widgetName;
    config["title"] = _title;

    if (_labelColon) {
        config["labelColon"] = true;
    }

    config["commands"] = commands;

    return config;
}
