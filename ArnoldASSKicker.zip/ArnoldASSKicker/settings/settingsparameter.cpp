#include "settingsparameter.h"

#include <QComboBox>
#include <QJsonArray>
#include <QJsonObject>
#include <QLineEdit>

SettingsParameter::SettingsParameter(Settings* settings, QJsonObject& config) :
    _settings(settings),
    _selectedOption(0)
{
    loadConfig(config);
}

SettingsParameter::Option SettingsParameter::option(int index)
{
    if (index < 0 || numOptions() <= index) return Option{};

    return _options[index];
}

SettingsParameter::Option SettingsParameter::selectedOption()
{
    return option(_selectedOption);
}

void SettingsParameter::setValue(bool value)
{
    if (!_type.startsWith("bool")) return;

    _value = value;
}

void SettingsParameter::setValue(int value)
{
    if (!_type.startsWith("int")) return;

    _value = value;
}

void SettingsParameter::setValue(double value)
{
    if (_type != "double" && _type != "float") return;

    _value = value;
}

void SettingsParameter::setValue(QString value)
{
    if (_type != "string") return;

    _value = value;
}

void SettingsParameter::selectOption(QString option)
{
    if (_type != "select") return;

    int n = numOptions();
    for (int i = 0; i < n; i++) {
        QString value = _options[i].value;
        if (value == option) {
            _selectedOption = i;
            _value = value;
        }
    }
}

void SettingsParameter::selectOptionIndex(int index)
{
    if (_type != "select") return;
    if (index < 0 || numOptions() <= index) return;

    _selectedOption = index;
    _value = _options[index].value;
}

void SettingsParameter::read()
{
    _value = _settings->value(_settingName, _defaultValue);
}

void SettingsParameter::write()
{
    _settings->setValue(_settingName, _value);
}

void SettingsParameter::readFromUI(QWidget* ui)
{
    if (_type == "select") {
        QComboBox* cb = ui->findChild<QComboBox*>(_widgetName);
        if (cb != nullptr) {
            selectOption(cb->currentText());
        }
        return;
    }

    QLineEdit* input = ui->findChild<QLineEdit*>(_widgetName);
    if (input == nullptr) return;

    QString value = input->text();
    if (_type == "string") {
        setValue(value);

    } else if (_type.startsWith("bool")) {
        setValue((bool)value.toInt());

    } else if (_type.startsWith("int")) {
        setValue(value.toInt());

    } else if (_type == "double" || _type == "float") {
        setValue(value.toDouble());
    }
}

void SettingsParameter::writeToUI(QWidget* ui)
{
    if (_type == "select") {
        QComboBox* cb = ui->findChild<QComboBox*>(_widgetName);
        if (cb != nullptr) {
            cb->setCurrentText(toString());
        }
    } else {
        QLineEdit* input = ui->findChild<QLineEdit*>(_widgetName);
        if (input != nullptr) {
            input->setText(toString());
        }
    }
}

void SettingsParameter::loadConfig(QJsonObject& config)
{
    _settingName = config["settingName"].toString();
    _widgetName = config["widgetName"].toString();
    _type = config["type"].toString();
    _defaultValue = config["default"].toVariant();

    if (_type != "select") return;

    _options.clear();

    if (config.contains("max")) {
        int min = config["min"].toInt();
        int max = config["max"].toInt();

        for (int i = min; i <= max; i++) {
            QString label = QString::number(i);
            QString value = label;
            _options.append(Option{label, value});
        }
    }

    QJsonArray options = config["options"].toArray();
    for (int i = 0; i < options.size(); i++) {
        QJsonObject config = options[i].toObject();
        QString label = config["label"].toString();
        QString value = config["value"].toString();
        _options.append(Option{label, value});
    }

    selectOption(_defaultValue.toString());
}

QJsonValue SettingsParameter::toJson()
{
    return QJsonValue::fromVariant(_value);
}

QJsonObject SettingsParameter::exportConfig()
{
    QJsonObject config;
    QJsonArray options;

    config["settingName"] = _settingName;
    config["widgetName"] = _widgetName;
    config["type"] = _type;
    config["default"] = QJsonValue::fromVariant(_defaultValue);

    int n = numOptions();
    for (int i = 0; i < n; i++) {
        QJsonObject option;
        option["label"] = _options[i].label;
        option["value"] = _options[i].value;

        options.append(option);
    }

    if (!options.empty()) {
        config["options"] = options;
    }

    return config;
}
