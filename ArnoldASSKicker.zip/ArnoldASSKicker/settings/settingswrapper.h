#ifndef SETTINGSWRAPPER_H
#define SETTINGSWRAPPER_H

#include <QSettings>

class SettingsWrapper
{
public:
    SettingsWrapper();
    virtual ~SettingsWrapper();

    void init(QString organization, QString application);

    QVariant value(QString name, const QVariant& defaultValue);
    bool boolValue(QString name, bool defaultValue = false);
    int intValue(QString name, int defaultValue = 0);
    double doubleValue(QString name, double defaultValue = 0);
    QString stringValue(QString name, const QString& defaultValue = QString());

    void beginGroup(QString name);
    void setValue(QString name, const QVariant& value);
    void endGroup();
    void remove(QString name);

protected:
    QSettings* _settings;
};

#endif // SETTINGSWRAPPER_H
