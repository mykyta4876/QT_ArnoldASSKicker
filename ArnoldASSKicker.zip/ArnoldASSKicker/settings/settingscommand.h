#ifndef SETTINGSCOMMAND_H
#define SETTINGSCOMMAND_H

#include "settingsparameter.h"

class SettingsCommand
{
public:
    using Settings = SettingsWrapper;

    SettingsCommand(Settings* settings, QJsonObject& config);
    ~SettingsCommand();

    QString name() { return _name; }
    QString settingName() { return _settingName; }
    QString widgetName() { return _widgetName; }
    QString label() { return _label; }
    QString statusTip() { return _statusTip; }

    int numParameters() { return _parameters.size(); }
    SettingsParameter* parameter(int index);

    bool enabled() { return _enabled; }
    bool enabledByDefault() { return _enabledByDefault; }
    void enable(bool enabled = true);
    void disable() { enable(false); }

    void read();
    void write();
    void readFromUI(QWidget* ui);
    void writeToUI(QWidget* ui);
    void loadConfig(QJsonObject& config);

    QString toArgString();
    QJsonObject toJson();
    QJsonObject exportConfig();

private:
    Settings* _settings;

    QString _name;
    QString _settingName;
    QString _widgetName;
    QString _label;
    QString _statusTip;

    QList<SettingsParameter*> _parameters;

    bool _enabled;
    bool _enabledByDefault;
};

#endif // SETTINGSCOMMAND_H
