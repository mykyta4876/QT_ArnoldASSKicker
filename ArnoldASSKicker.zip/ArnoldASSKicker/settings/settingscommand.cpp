#include "settingscommand.h"

#include <QCheckBox>
#include <QJsonArray>
#include <QJsonObject>

SettingsCommand::SettingsCommand(Settings* settings, QJsonObject& config) :
    _settings(settings),
    _enabled(false),
    _enabledByDefault(false)
{
    loadConfig(config);
}

SettingsCommand::~SettingsCommand()
{
    for (const SettingsParameter* parameter : _parameters) {
        delete parameter;
    }
}

SettingsParameter* SettingsCommand::parameter(int index)
{
    if (index < 0 || numParameters() <= index) return nullptr;

    return _parameters[index];
}

void SettingsCommand::enable(bool enabled)
{
    _enabled = enabled;
}

void SettingsCommand::read()
{
    _enabled = _settings->boolValue(_settingName, _enabledByDefault);

    for (SettingsParameter* parameter : _parameters) {
        parameter->read();
    }
}

void SettingsCommand::write()
{
    _settings->setValue(_settingName, _enabled);

    for (SettingsParameter* parameter : _parameters) {
        parameter->write();
    }
}

void SettingsCommand::readFromUI(QWidget* ui)
{
    QCheckBox* cb = ui->findChild<QCheckBox*>(_widgetName);
    if (cb != nullptr) {
        enable(cb->isChecked());
    }

    for (SettingsParameter* parameter : _parameters) {
        parameter->readFromUI(ui);
    }
}

void SettingsCommand::writeToUI(QWidget* ui)
{
    QCheckBox* cb = ui->findChild<QCheckBox*>(_widgetName);
    if (cb != nullptr) {
        cb->setChecked(enabled());
    }

    for (SettingsParameter* parameter : _parameters) {
        parameter->writeToUI(ui);
    }
}

void SettingsCommand::loadConfig(QJsonObject& config)
{
    _name = config["name"].toString();
    _settingName = config["settingName"].toString();
    _widgetName = config["widgetName"].toString();
    _label = config["label"].toString();
    _enabled = _enabledByDefault = config["enabled"].toBool();

    QJsonValue statusTip = config["statusTip"];
    if (statusTip.isArray()) {
        QJsonArray strings = statusTip.toArray();
        for (int i = 0; i < strings.size(); i++) {
            _statusTip += strings[i].toString();
        }
    } else {
        _statusTip = config["statusTip"].toString();
    }

    _parameters.clear();

    QJsonArray parameters = config["parameters"].toArray();
    for (int i = 0; i < parameters.size(); i++) {
        QJsonObject config = parameters[i].toObject();
        SettingsParameter* parameter = new SettingsParameter(_settings, config);
        _parameters.append(parameter);
    }
}

QString SettingsCommand::toArgString()
{
    if (!enabled()) return "";
    if (_name.isEmpty()) return "";

    QString arg = '-' + _name;

    for (SettingsParameter* parameter : _parameters) {
        QString str = parameter->toString();
        if (!str.isEmpty()) {
            arg += ' ' + str;
        }
    }

    return arg;
}

QJsonObject SettingsCommand::toJson()
{
    QJsonObject json;
    QJsonArray parameters;

    for (SettingsParameter* parameter : _parameters) {
        parameters.append(parameter->toJson());
    }

    json["enabled"] = _enabled;
    json["parameters"] = parameters;

    return json;
}

QJsonObject SettingsCommand::exportConfig()
{
    QJsonObject config;
    QJsonArray parameters;

    for (SettingsParameter* parameter : _parameters) {
        parameters.append(parameter->exportConfig());
    }

    config["name"] = _name;
    config["settingName"] = _settingName;
    config["widgetName"] = _widgetName;
    config["label"] = _label;
    config["statusTip"] = _statusTip;

    if (_enabledByDefault) {
        config["enabled"] = true;
    }

    config["parameters"] = parameters;

    return config;
}
