#include "settingswrapper.h"

SettingsWrapper::SettingsWrapper() :
    _settings(nullptr)
{}

SettingsWrapper::~SettingsWrapper()
{
    if (_settings != nullptr) {
        delete _settings;
    }
}

void SettingsWrapper::init(QString organization, QString application)
{
    if (_settings != nullptr) {
        delete _settings;
    }

    _settings = new QSettings(
        QSettings::IniFormat,
        QSettings::UserScope,
        organization,
        application);
}

QVariant SettingsWrapper::value(QString name, const QVariant& defaultValue)
{
    return _settings->value(name, defaultValue);
}

bool SettingsWrapper::boolValue(QString name, bool defaultValue)
{
    return value(name, defaultValue).toBool();
}

int SettingsWrapper::intValue(QString name, int defaultValue)
{
    return value(name, defaultValue).toInt();
}

double SettingsWrapper::doubleValue(QString name, double defaultValue)
{
    return value(name, defaultValue).toDouble();
}

QString SettingsWrapper::stringValue(QString name, const QString& defaultValue)
{
    return value(name, defaultValue).toString();
}

void SettingsWrapper::beginGroup(QString name)
{
    _settings->beginGroup(name);
}

void SettingsWrapper::setValue(QString name, const QVariant& value)
{
    _settings->setValue(name, value);
}

void SettingsWrapper::endGroup()
{
    _settings->endGroup();
}

void SettingsWrapper::remove(QString name)
{
    _settings->remove(name);
}
