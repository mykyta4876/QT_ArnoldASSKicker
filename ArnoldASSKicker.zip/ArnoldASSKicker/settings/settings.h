#ifndef SETTINGS_H
#define SETTINGS_H

#include "settingsgroup.h"

class Settings : public SettingsWrapper
{
public:
    Settings();
    ~Settings();

    QString organizationName() { return _organizationName; }
    QString organizationDomain() { return _organizationDomain; }
    QString applicationName() { return _applicationName; }
    QString settingsOrganization() { return _settingsOrganization; }
    QString settingsApplication() { return _settingsApplication; }
    QString windowTitle() { return _windowTitle; }
    QString titleLabel() { return _titleLabel; }
    QString version() { return _version; }
    QString buildVersion() { return _buildVersion; }
    QString kickVersion() { return _kickVersion; }
    QString arnoldVersion() { return _arnoldVersion; }

    QString kickPath() { return _kickPath; }
    QString shaderPath() { return _shaderPath; }
    QString lastUsedDir() { return _lastUsedDir; }
    bool ignoreLicHost() { return _ignoreLicHost; }
    bool useLastUsedDir() { return _useLastUsedDir; }
    bool clearOnRender() { return _clearOnRender; }
    bool notifyOnSeqCompletion() { return _notifyOnSeqCompletion; }

    int numGroups() { return _groups.size(); }
    SettingsGroup* group(int index);

    void setKickPath(QString kickPath);
    void setShaderPath(QString shaderPath);
    void setLastUsedDir(QString lastUsedDir);
    void ignoreLicHost(bool ignoreLicHost);
    void useLastUsedDir(bool useLastUsedDir);
    void clearOnRender(bool clearOnRender);
    void notifyOnSeqCompletion(bool notifyOnSeqCompletion);

    void loadConfig();
    void read();
    void write();
    void reset();
    void readFromUI(QWidget* ui);
    void writeToUI(QWidget* ui);

    QString toArgString();

    QJsonObject toJson();
    QString toJsonString();

    QJsonArray exportConfig();
    QString exportConfigString();

private:
    QString _organizationName;
    QString _organizationDomain;
    QString _applicationName;
    QString _settingsOrganization;
    QString _settingsApplication;
    QString _windowTitle;
    QString _titleLabel;
    QString _version;
    QString _buildVersion;
    QString _kickVersion;
    QString _arnoldVersion;

    QString _kickPath;
    QString _shaderPath;
    QString _lastUsedDir;
    bool _ignoreLicHost;
    bool _useLastUsedDir;
    bool _clearOnRender;
    bool _notifyOnSeqCompletion;

    QList<SettingsGroup*> _groups;

    void loadAppConfig();
    void loadSettingsConfig();
};

#endif // SETTINGS_H
