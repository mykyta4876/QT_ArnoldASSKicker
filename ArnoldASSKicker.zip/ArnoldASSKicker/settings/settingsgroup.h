#ifndef SETTINGSGROUP_H
#define SETTINGSGROUP_H

#include "settingscommand.h"

class SettingsGroup
{
public:
    using Settings = SettingsWrapper;

    SettingsGroup(Settings* settings, QJsonObject& config);
    ~SettingsGroup();

    QString name() { return _name; }
    QString widgetName() { return _widgetName; }
    QString title() { return _title; }

    bool labelColon() { return _labelColon; }

    int numCommands() { return _commands.size(); }
    SettingsCommand* command(int index);

    void read();
    void write();
    void clear();
    void readFromUI(QWidget* ui);
    void writeToUI(QWidget* ui);
    void loadConfig(QJsonObject& config);

    QString toArgString();
    QJsonObject toJson();
    QJsonObject exportConfig();

private:
    Settings* _settings;

    QString _name;
    QString _widgetName;
    QString _title;
    bool _labelColon;

    QList<SettingsCommand*> _commands;
};

#endif // SETTINGSGROUP_H
