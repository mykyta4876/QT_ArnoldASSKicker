#include "settings.h"

#include <QFile>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>

//------------------------------
//Util

QString getField(QJsonObject& config, QString name)
{
    QString value = config[name].toString();
    QRegularExpression regex(R"(\{\w+\})");

    int maxReplacements = 100;
    for (int i = 0; i < maxReplacements; i++) {
        QRegularExpressionMatch match = regex.match(value);
        if (!match.hasMatch()) break;

        QString matchString = match.captured(0);
        QString key = matchString.mid(1, matchString.length() - 2);
        QString replacement = config[key].toString();

        value.replace(matchString, replacement);
    }

    return value;
}

//------------------------------
//Settings

Settings::Settings() :
    _ignoreLicHost(false),
    _useLastUsedDir(false),
    _clearOnRender(false),
    _notifyOnSeqCompletion(false)
{
    loadConfig();
    init(_settingsOrganization, _settingsApplication);
    read();
}

Settings::~Settings()
{
    for (const SettingsGroup* group : _groups) {
        delete group;
    }
}

SettingsGroup* Settings::group(int index)
{
    if (index < 0 || numGroups() <= index) return nullptr;

    return _groups[index];
}

void Settings::setKickPath(QString kickPath)
{
    _kickPath = kickPath;
}

void Settings::setShaderPath(QString shaderPath)
{
    _shaderPath = shaderPath;
}

void Settings::setLastUsedDir(QString lastUsedDir)
{
    _lastUsedDir = lastUsedDir;
}

void Settings::ignoreLicHost(bool ignoreLicHost)
{
    _ignoreLicHost = ignoreLicHost;
}

void Settings::useLastUsedDir(bool useLastUsedDir)
{
    _useLastUsedDir = useLastUsedDir;
}

void Settings::clearOnRender(bool clearOnRender)
{
    _clearOnRender = clearOnRender;
}

void Settings::notifyOnSeqCompletion(bool notifyOnSeqCompletion)
{
    _notifyOnSeqCompletion = notifyOnSeqCompletion;
}

void Settings::loadConfig()
{
    loadAppConfig();
    loadSettingsConfig();
}

void Settings::read()
{
    beginGroup("prefs");
    _kickPath = stringValue("kickPath");
    _shaderPath = stringValue("shaderPath");
    _lastUsedDir = stringValue("lastUsedDir");
    _ignoreLicHost = boolValue("prefsIgnoreLicHostCheckBox");
    _useLastUsedDir = boolValue("lastUsedDirCheckBox", true);
    endGroup();

    beginGroup("mainWindow");
    _clearOnRender = boolValue("clearOnRender", true);
    _notifyOnSeqCompletion = boolValue("notifyOnSeqCompletion", true);
    endGroup();

    for (SettingsGroup* group : _groups) {
        group->read();
    }
}

void Settings::write()
{
    beginGroup("prefs");
    setValue("kickPath", _kickPath);
    setValue("shaderPath", _shaderPath);
    setValue("lastUsedDir", _lastUsedDir);
    setValue("prefsIgnoreLicHostCheckBox", _ignoreLicHost);
    setValue("lastUsedDirCheckBox", _useLastUsedDir);
    endGroup();

    beginGroup("mainWindow");
    setValue("clearOnRender", _clearOnRender);
    setValue("notifyOnSeqCompletion", _notifyOnSeqCompletion);
    endGroup();

    for (SettingsGroup* group : _groups) {
        group->write();
    }

    _settings->sync();
}

void Settings::reset()
{
    remove("mainWindow");

    for (SettingsGroup* group : _groups) {
        group->clear();
    }
}

void Settings::readFromUI(QWidget* ui)
{
    for (SettingsGroup* group : _groups) {
        group->readFromUI(ui);
    }
}

void Settings::writeToUI(QWidget* ui)
{
    for (SettingsGroup* group : _groups) {
        group->writeToUI(ui);
    }
}

QString Settings::toArgString()
{
    QString args = "-l " + _shaderPath;

    if (_ignoreLicHost) {
        args += " -sl";
    }

    for (SettingsGroup* group : _groups) {
        QString str = group->toArgString();
        if (!str.isEmpty()) {
            args += ' ' + str;
        }
    }

    return args;
}

QJsonObject Settings::toJson()
{
    QJsonObject json;

    json["organizationName"] = _organizationName;
    json["organizationDomain"] = _organizationDomain;
    json["applicationName"] = _applicationName;
    json["settingsOrganization"] = _settingsOrganization;
    json["settingsApplication"] = _settingsApplication;
    json["windowTitle"] = _windowTitle;
    json["titleLabel"] = _titleLabel;
    json["version"] = _version;
    json["buildVersion"] = _buildVersion;
    json["kickVersion"] = _kickVersion;
    json["arnoldVersion"] = _arnoldVersion;
    json["kickPath"] = _kickPath;
    json["shaderPath"] = _shaderPath;
    json["lastUsedDir"] = _lastUsedDir;
    json["ignoreLicHost"] = _ignoreLicHost;
    json["useLastUsedDir"] = _useLastUsedDir;
    json["clearOnRender"] = _clearOnRender;
    json["notifyOnSeqCompletion"] = _notifyOnSeqCompletion;

    for (SettingsGroup* group : _groups) {
        json[group->name()] = group->toJson();
    }

    return json;
}

QString Settings::toJsonString()
{
    QJsonObject json = toJson();
    QJsonDocument doc(json);
    return doc.toJson();
}

QJsonArray Settings::exportConfig()
{
    QJsonArray config;

    for (SettingsGroup* group : _groups) {
        config.append(group->exportConfig());
    }

    return config;
}

QString Settings::exportConfigString()
{
    QJsonArray json = exportConfig();
    QJsonDocument doc(json);
    return doc.toJson();
}

void Settings::loadAppConfig()
{
    QString filePath = ":/config/config.json";
    QFile loadFile(filePath);

    if (!loadFile.open(QIODevice::ReadOnly)) {
        QString err = "Couldn't open config file: " + filePath;
        qWarning() << err;
        return;
    }

    QByteArray fileData = loadFile.readAll();
    QJsonDocument doc(QJsonDocument::fromJson(fileData));
    QJsonObject config = doc.object();

    _organizationName = getField(config, "organizationName");
    _organizationDomain = getField(config, "organizationDomain");
    _applicationName = getField(config, "applicationName");
    _settingsOrganization = getField(config, "settingsOrganization");
    _settingsApplication = getField(config, "settingsApplication");
    _windowTitle = getField(config, "windowTitle");
    _titleLabel = getField(config, "titleLabel");
    _version = getField(config, "version");
    _buildVersion = getField(config, "buildVersion");
    _kickVersion = getField(config, "kickVersion");
    _arnoldVersion = getField(config, "arnoldVersion");
}

void Settings::loadSettingsConfig()
{
    QString filePath = ":/config/settings.json";
    QFile loadFile(filePath);

    if (!loadFile.open(QIODevice::ReadOnly)) {
        QString err = "Couldn't open config file: " + filePath;
        qWarning() << err;
        return;
    }

    QByteArray fileData = loadFile.readAll();
    QJsonDocument doc(QJsonDocument::fromJson(fileData));
    QJsonArray config = doc.array();

    _groups.clear();

    for (int i = 0; i < config.size(); i++) {
        QJsonObject groupConfig = config[i].toObject();
        SettingsGroup* group = new SettingsGroup(this, groupConfig);
        _groups.append(group);
    }
}
