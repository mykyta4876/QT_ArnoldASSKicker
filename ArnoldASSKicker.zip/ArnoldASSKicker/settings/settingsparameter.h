#ifndef SETTINGSPARAMETER_H
#define SETTINGSPARAMETER_H

#include "settingswrapper.h"

class SettingsParameter
{
public:
    using Settings = SettingsWrapper;

    struct Option {
        QString label;
        QString value;
    };

    SettingsParameter(Settings* settings, QJsonObject& config);

    QString settingName() { return _settingName; }
    QString widgetName() { return _widgetName; }
    QString type() { return _type; }
    QVariant defaultValue() { return _defaultValue; }
    QVariant value() { return _value; }
    QString toString() { return _value.toString(); }

    int numOptions() { return _options.size(); }
    int selectedOptionIndex() { return _selectedOption; }
    Option option(int index);
    Option selectedOption();

    void setValue(bool value);
    void setValue(int value);
    void setValue(double value);
    void setValue(QString value);
    void selectOption(QString option);
    void selectOptionIndex(int index);

    void read();
    void write();
    void readFromUI(QWidget* ui);
    void writeToUI(QWidget* ui);
    void loadConfig(QJsonObject& config);

    QJsonValue toJson();
    QJsonObject exportConfig();

private:
    Settings* _settings;

    QString _settingName;
    QString _widgetName;
    QString _type;
    QVariant _defaultValue;
    QVariant _value;
    QList<Option> _options;
    int _selectedOption;
};

#endif // SETTINGSPARAMETER_H
