#include "sequencemap.h"

#include <algorithm>

#include <QJsonArray>

SequenceMap::SequenceMap() :
    _startFrame(0),
    _numFrames(0),
    _maxFrame(MAX_FRAMES),
    _startFile(0),
    //_numFiles(0),
    _maxFile(MAX_FILES),
    _isSequence(false)
{}

bool SequenceMap::isSequence()
{
    return _isSequence && numFrames() > 1;
}

bool SequenceMap::isSingleFile()
{
    return !isSequence();
}

bool SequenceMap::isAppendable()
{
    return isSequence() || numFrames() == 1;
}

int SequenceMap::startFrame()
{
    if (_numFrames == ALL_FRAMES) return 0;

    return std::min(_startFrame, _maxFrame);
}

int SequenceMap::endFrame()
{
    if (_numFrames == ALL_FRAMES) return 0;

    int end = _startFrame + _numFrames - 1;
    return std::min(end, _maxFrame);
}

int SequenceMap::numFrames()
{
    //return _numFrames;
    return endFrame() - startFrame() + 1;
}

bool SequenceMap::hasFrame(int frameNum)
{
    if (_numFrames == ALL_FRAMES) return true;

    return startFrame() <= frameNum && frameNum <= endFrame();
}

int SequenceMap::numFiles()
{
    int numFrames = this->numFrames();
    if (numFrames <= 0) return 0;
    if (!_isSequence) return 1;
    return numFrames;
}

int SequenceMap::fileIndex(int frameNum)
{
    if (!hasFrame(frameNum)) return -1;

    int numFiles = this->numFiles();
    if (numFiles == 0) return -1;

    int fileIndex = _startFile;
    if (_isSequence) {
        int frameOffset = frameNum - startFrame();
        fileIndex += frameOffset;
    }
    if (fileIndex >= _maxFile) return -1;

    return fileIndex;
}

void SequenceMap::setFrameRange(int start, int num)
{
    if (start >= 0) {
        _startFrame = start;
    }
    if (num > 0 || num == ALL_FRAMES) {
        _numFrames = num;
    }
}

void SequenceMap::setFileRange(int start, int num)
{
    //if (start < 0) return;

    //_startFile = start;
    //_numFrames = std::max(_numFrames, num);

    if (start >= 0) {
        _startFile = start;
    }
    if (num <= 0) {
        _isSequence = true;

    } else if (num == 1) {
        _isSequence = false;

    } else if (num == numFrames()) {
        _isSequence = true;
    }

    //for (int i = 1; i < _numFrames; i++) {
    //    int frameNum = _startFrame + i;
    //    int fileIndex = start + i;
    //    append(frameNum, fileIndex);
    //}
}

void SequenceMap::setMaxFrame(int frameNum)
{
    if (frameNum >= 0) {
        _maxFrame = frameNum;
    }
}

void SequenceMap::setMaxFile(int index)
{
    if (index >= 0) {
        _maxFile = index;
    }
}

bool SequenceMap::append(int frameNum, int fileIndex)
{
    if (frameNum > _maxFrame) return false;
    if (fileIndex > _maxFile) return false;
    if (!isAppendable()) return false;
    if (frameNum != endFrame() + 1) return false;
    if (fileIndex - _startFile != numFrames()) return false;

    _numFrames++;
    _isSequence = true;
    return true;
}

QJsonObject SequenceMap::debugJson()
{
    QJsonObject state;

    state["_startFrame"] = _startFrame;
    state["_numFrames"] = _numFrames;
    state["_maxFrame"] = _maxFrame;
    state["_startFile"] = _startFile;
    state["_maxFile"] = _maxFile;
    state["_isSequence"] = _isSequence;
    state["isSequence"] = isSequence();
    state["isSingleFile"] = isSingleFile();
    state["isAppendable"] = isAppendable();
    state["startFrame"] = startFrame();
    state["endFrame"] = endFrame();
    state["numFrames"] = numFrames();
    state["numFiles"] = numFiles();

    QJsonArray fileIndex;

    int end = endFrame();
    for (int frameNum = startFrame(); frameNum <= end; frameNum++) {
        //if (!hasFrame(frameNum)) continue;

        fileIndex.append(this->fileIndex(frameNum));
    }

    QJsonObject json;

    json["_"] = state;
    json["fileIndex"] = fileIndex;

    return json;
}
