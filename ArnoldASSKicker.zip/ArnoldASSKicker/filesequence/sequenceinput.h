#ifndef SEQUENCEINPUT_H
#define SEQUENCEINPUT_H

#include "sequenceframe.h"
#include "sequencemap.h"
//#include "sequenceutil.h"

#include <QJsonObject>

class FileSequence;

class SequenceInput
{
public:
    using Frame = SequenceFrame;
    //using ParseResult = SequenceUtil::ParseResult;

    SequenceInput(FileSequence& ref);

    bool isSequence();

    QString name();
    QString fileName();
    QString baseName();
    QString sequenceName();
    QString displayName();

    int startFrame();
    int endFrame();
    int numFrames();
    int numFramesSkipped();
    bool hasFrame(int frameNum);
    Frame frame(int frameNum);
    QStringList frameFiles(int frameNum);

    //void addParseResult(int fileIndex, ParseResult result);
    void append(int fileIndex, int startFrame, int numFrames);

    QJsonObject debugJson();

private:
    FileSequence& _ref;
    QList<SequenceMap> _frameMap;

    friend Frame;
};

#endif // SEQUENCEINPUT_H
