#ifndef FILESEQUENCE_H
#define FILESEQUENCE_H

#include "sequenceinput.h"

class FileSequence
{
public:
    using Input = SequenceInput;
    using Frame = SequenceFrame;

    FileSequence();
    ~FileSequence();

    bool isSequence();

    int numFiles();
    int numInputs();
    int numFrames();
    int startFrame();
    int endFrame();

    QStringList fileNames();
    QStringList displayNames();
    QString fileName(int index);
    Input* input(int index);
    Input* sequence(QString name);
    QStringList frameFiles(int frameNum);

    void add(QString fileName);
    void add(QStringList fileNames);
    void set(QStringList fileNames);
    void removeSequenceName(QString name);
    void clear();

    QString debugString();

private:
    QStringList _fileNames;
    QList<Input*> _inputs;

    void clearInputs();
    void update();
};

/*
    isSequence
    name (file or sequence)
    fileName or ""
    sequenceName or ""
    displayName
    maxFrame/endFrame
    minFrame/startFrame
    numFrames/length
    numFramesSkipped
    hasFrame(j)
    frame(j)
        numFiles
        fileName(k = 0)
        fileNames()
        fileIndex(k = 0)
        fileIndexes()
*/

#endif // FILESEQUENCE_H
