#include "sequenceframe.h"
#include "filesequence.h"

#include <QJsonArray>

SequenceFrame::SequenceFrame(Input& input, int frameNum) :
    _input(input),
    _frameNum(frameNum)
{}

bool SequenceFrame::hasFiles()
{
    return numFiles() > 0;
}

int SequenceFrame::numFiles()
{
    int numFiles = 0;
    for (SequenceMap& map : _input._frameMap) {
        numFiles += map.hasFrame(_frameNum);
    }
    return numFiles;
}

int SequenceFrame::fileIndex(int index)
{
    if (index < 0) return -1;

    int fileIndex = -1;
    for (SequenceMap& map : _input._frameMap) {
        if (map.hasFrame(_frameNum)) {
            index--;
        }
        if (index < 0) {
            fileIndex = map.fileIndex(_frameNum);
            break;
        }
    }
    return fileIndex;
}

QString SequenceFrame::fileName(int index)
{
    int fileIndex = this->fileIndex(index);
    if (fileIndex < 0) return QString();

    return _input._ref.fileName(fileIndex);
}

QStringList SequenceFrame::fileNames()
{
    QStringList fileNames;

    //TODO: more efficient implementation
    int n = numFiles();
    for (int i = 0; i < n; i++) {
        fileNames.append(fileName(i));
    }
    return fileNames;
}

QJsonObject SequenceFrame::debugJson()
{
    QJsonObject state;

    state["frameNum"] = frameNum();
    state["hasFiles"] = hasFiles();
    state["numFiles"] = numFiles();

    QJsonArray fileIndex;
    QJsonArray fileNames = QJsonArray::fromStringList(this->fileNames());

    int n = numFiles();
    for (int i = 0; i < n; i++) {
        fileIndex.append(this->fileIndex(i));
    }

    QJsonObject json;

    json["_"] = state;
    json["fileIndex"] = fileIndex;
    json["fileNames"] = fileNames;

    return json;
}
