#ifndef SEQUENCEUTIL_H
#define SEQUENCEUTIL_H

#include <QRegularExpression>
#include <QStringList>

class SequenceUtil
{
public:
    struct FileInfo {
        QString baseName;
        QString completeBaseName;
        QString completeSuffix;
        QString fileName;
        QString filePath;
        QString path;
        QString suffix;

        bool isValid();
    };

    struct ParseResult {
        QString sequenceName;
        int startFrame = 0;
        int endFrame = 0;
        int numFrames = 0;
        int startFrameLeadingZeros = 0;
        int endFrameLeadingZeros = 0;
    };

    static FileInfo fileInfo(QString filePath);
    static ParseResult parse(QString fileName);
    static QString originalFileName(QString normalized);
    static bool isNormalized(QString fileName);
    static void sort(QStringList& fileNames);
    static void normalize(QStringList& fileNames);

private:
    static QRegularExpression re;
    static QRegularExpression reNorm;
};

#endif // SEQUENCEUTIL_H
