#ifndef SEQUENCEFRAME_H
#define SEQUENCEFRAME_H

#include <QJsonObject>
#include <QStringList>

class SequenceInput;

class SequenceFrame
{
public:
    using Input = SequenceInput;

    SequenceFrame(Input& input, int frameNum);

    int frameNum() { return _frameNum; }
    bool hasFiles();
    int numFiles();
    int fileIndex(int index = 0);
    QString fileName(int index = 0);
    QStringList fileNames();

    QJsonObject debugJson();

private:
    Input& _input;
    int _frameNum;
};

#endif // SEQUENCEFRAME_H
