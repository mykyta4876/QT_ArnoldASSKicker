#include "sequenceutil.h"

//#include <QFile>
#include <QFileInfo>
#include <QRegularExpressionMatch>

using FileInfo = SequenceUtil::FileInfo;
using ParseResult = SequenceUtil::ParseResult;

QRegularExpression SequenceUtil::re{};
QRegularExpression SequenceUtil::reNorm{};

bool FileInfo::isValid()
{
    return !completeBaseName.isEmpty() &&
        suffix.toLower() == "ass";
}

FileInfo SequenceUtil::fileInfo(QString filePath_)
{
    QFileInfo fileInfo(filePath_);
    QString baseName = fileInfo.baseName();
    QString completeBaseName = fileInfo.completeBaseName();
    QString completeSuffix = fileInfo.completeSuffix();
    QString fileName = fileInfo.fileName();
    QString filePath = fileInfo.filePath();
    QString path = fileInfo.path();
    QString suffix = fileInfo.suffix();

    return FileInfo{
        baseName,
        completeBaseName,
        completeSuffix,
        fileName,
        filePath,
        path,
        suffix
    };
}

int numLeadingZeros(const QString& input)
{
    int count = 0;
    for (QChar ch : input) {
        if (ch == '0') {
            count++;
        } else break;
    }
    return count;
}

ParseResult SequenceUtil::parse(QString fileName)
{
    if (isNormalized(fileName)) {
        fileName = originalFileName(fileName);
    }

    // Test for sequences with a .####. notation. 1 - 8 digits supported.
    if (re.pattern().isEmpty()) {
        QString pattern = R"(^(.+?)(?:\b(\d{1,8})(?:-(\d{1,8}))?)?\.ass$)";
        auto option = QRegularExpression::CaseInsensitiveOption;
        re = QRegularExpression(pattern, option);
    }

    QRegularExpressionMatch match = re.match(fileName);
    if (!match.hasMatch()) return {};

    //QString fileName = match.captured(0);
    QString sequenceName = match.captured(1);
    if (sequenceName.endsWith('.')) {
        sequenceName.chop(1);
    }

    int startFrame = 0;
    int startFrameLeadingZeros = 0;
    if (match.hasCaptured(2)) {
        QString str = match.captured(2);
        startFrame = str.toInt();
        startFrameLeadingZeros = numLeadingZeros(str);
    }

    int endFrame = startFrame;
    int endFrameLeadingZeros = 0;
    if (match.hasCaptured(3)) {
        QString str = match.captured(3);
        endFrame = str.toInt();
        endFrameLeadingZeros = numLeadingZeros(str);
    }

    if (endFrame < startFrame) {
        endFrame = startFrame = 0;
    }

    if (startFrame == 0) {
        startFrame = qMin(1, endFrame);
    }

    int numFrames = 0;
    if (startFrame > 0) {
        numFrames = endFrame - startFrame + 1;
    }

    return ParseResult{
        sequenceName,
        startFrame,
        endFrame,
        numFrames,
        startFrameLeadingZeros,
        endFrameLeadingZeros
    };
}

QString SequenceUtil::originalFileName(QString normalized)
{
    QString& fileName = normalized;
    QStringList leadingZeros = fileName.section(' ', -1).split('-');
    fileName = fileName.section(' ', 0, -2);
    QString baseName = fileName.section('.', 0, -3);
    QStringList frameRange = fileName.section('.', -2, -2).split('-');

    static QRegularExpression re("^0+");
    QString zeros = QString(leadingZeros[0].toInt(), '0');
    QString frameRangeStr = zeros + frameRange[0].remove(re);
    if (leadingZeros[1] != 'X') {
        zeros = QString(leadingZeros[1].toInt(), '0');
        frameRangeStr += '-' + zeros + frameRange[1].remove(re);
    }

    if (frameRangeStr.isEmpty()) return baseName + ".ass";

    return QString("%1.%2.ass").arg(
        baseName,
        frameRangeStr);
}

bool SequenceUtil::isNormalized(QString fileName)
{
    if (reNorm.pattern().isEmpty()) {
        QString pattern = R"(\.ass \d-[0-9xX]$)";
        auto option = QRegularExpression::CaseInsensitiveOption;
        reNorm = QRegularExpression(pattern, option);
    }

    QRegularExpressionMatch match = reNorm.match(fileName);
    return match.hasMatch();
}

void SequenceUtil::sort(QStringList& fileNames)
{
    //Sort in ascending alphanumeric order
    //Remove duplicates

    //for (int i = 0; i < fileNames.size(); i++) {
    //    ParseResult result = parse(fileNames[i]);
    //}

    fileNames.removeAll("");
    fileNames.removeDuplicates();

    //TODO: sort alphanumerically
    fileNames.sort();

    //baseName.########-########.ass (#-#)
}

void SequenceUtil::normalize(QStringList& fileNames)
{
    for (int i = 0; i < fileNames.size(); i++) {
        QString& fileName = fileNames[i];
        if (isNormalized(fileName)) continue;

        auto fileInfo = SequenceUtil::fileInfo(fileName);
        if (!fileInfo.isValid()) {
            fileNames[i].clear();
            continue;
        }

        auto parseResult = SequenceUtil::parse(fileInfo.filePath);
        QString sequenceName = parseResult.sequenceName;
        if (sequenceName.isEmpty()) {
            fileNames[i].clear();
            continue;
        }

        int startFrame = parseResult.startFrame;
        int endFrame = parseResult.endFrame;
        int numFrames = parseResult.numFrames;
        int numZeros1 = parseResult.startFrameLeadingZeros;
        int numZeros2 = parseResult.endFrameLeadingZeros;

        QString start = QString::number(startFrame).rightJustified(8, '0');
        QString end = QString::number(endFrame).rightJustified(8, '0');
        QString zeros1 = QString::number(numZeros1);
        QString zeros2 = numFrames > 1 ? QString::number(numZeros2) : "X";

        QString fileName2 = QString("%1.%2-%3.ass").arg(
            sequenceName,
            start,
            end);

        bool isDuplicate = false;
        for (const QString& fileName : fileNames) {
            if (fileName.startsWith(fileName2)) {
                isDuplicate = true; break;
            }
        }

        if (isDuplicate) {
            fileNames[i].clear();
            continue;
        }

        fileNames[i] = QString("%1 %2-%3").arg(
            fileName2,
            zeros1,
            zeros2);
    }

    sort(fileNames);
}
