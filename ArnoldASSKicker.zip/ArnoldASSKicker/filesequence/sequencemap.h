#ifndef SEQUENCEMAP_H
#define SEQUENCEMAP_H

#include <QJsonObject>

class SequenceMap
{
    static const int MAX_FRAMES = 1000000;
    static const int MAX_FILES = 1000000;
    static const int ALL_FRAMES = 0;
    //static const int ONE_FILE_PER_FRAME = 0;

public:
    SequenceMap();

    bool isSequence();
    bool isSingleFile();
    bool isAppendable();

    int startFrame();
    int endFrame();
    int numFrames();
    bool hasFrame(int frameNum);
    int numFiles();
    int fileIndex(int frameNum);

    void setFrameRange(int start, int num = 1);
    void setFileRange(int start, int num = 0);
    void setMaxFrame(int frameNum);
    void setMaxFile(int index);

    bool append(int frameNum, int fileIndex);

    QJsonObject debugJson();

private:
    int _startFrame;
    int _numFrames;
    int _maxFrame;
    int _startFile;
    //int _numFiles;
    int _maxFile;
    bool _isSequence;
};

#endif // SEQUENCEMAP_H
