#ifndef FILESEQUENCEVIEW_H
#define FILESEQUENCEVIEW_H

#include "layout.h"

#include <QLabel>
#include <QListWidget>
#include <QPushButton>

class FileSequenceView
{
public:
    class Events {
    public:
        virtual ~Events() {}

        virtual void browse() = 0;
        virtual void clear() = 0;
        virtual void remove(int index, QString path) = 0;
        virtual void finishedRemoving() = 0;
    };

    FileSequenceView(QWidget* parent = nullptr);
    ~FileSequenceView();

    QWidget* widget();
    Events* events();

    void setEvents(Events* events);
    void setVersion(QString version);
    void setLength(int length);
    void add(QString path);
    void clear();
    void render();

    void loadLayout(QJsonObject& config);

    QString layoutDebugString() { return _layout->debugString(); }

private:
    QWidget* _widget;
    Events* _events;
    Layout* _layout;

    QLabel* _label;
    QLabel* _version;
    QLabel* _lengthLabel;
    QLabel* _lengthValue;
    QListWidget* _sequence;
    QPushButton* _remove;
    QPushButton* _clear;
    QPushButton* _browse;

    void performLayout();
    void setupStyleSheet();
};

#endif // FILESEQUENCEVIEW_H
