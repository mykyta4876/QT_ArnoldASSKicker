#include "filesequenceview.h"
#include "layoutload.h"

FileSequenceView::FileSequenceView(QWidget* parent) :
    _widget(new QWidget(parent)),
    _events(nullptr),
    _layout(new Layout("fileSequence", _widget)),
    _label(new QLabel(_widget)),
    _version(new QLabel(_widget)),
    _lengthLabel(new QLabel(_widget)),
    _lengthValue(new QLabel(_widget)),
    _sequence(new QListWidget(_widget)),
    _remove(new QPushButton(_widget)),
    _clear(new QPushButton(_widget)),
    _browse(new QPushButton(_widget))
{
    _widget->setObjectName("fileSequence");
    _label->setObjectName("fileSequence_label");
    _version->setObjectName("fileSequence_version");
    _lengthLabel->setObjectName("fileSequence_sequenceLength_label");
    _lengthValue->setObjectName("fileSequence_sequenceLength_value");
    _sequence->setObjectName("fileSequence_sequence");
    _remove->setObjectName("fileSequence_remove");
    _clear->setObjectName("fileSequence_clear");
    _browse->setObjectName("fileSequence_browse");

    //width = aspect 29/3, height = 100%
    _version->setPixmap(QPixmap(":/logo"));
    _version->setScaledContents(true);
    _version->setAlignment(Qt::AlignCenter);
    _lengthLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
    _remove->setFlat(true);
    _clear->setFlat(true);
    _browse->setFlat(true);

    _sequence->setAcceptDrops(true);
    _sequence->setDragEnabled(true);
    _sequence->setDragDropMode(QAbstractItemView::DragOnly);
    _sequence->setAlternatingRowColors(true);
    _sequence->setSelectionMode(QAbstractItemView::ExtendedSelection);

    _label->setText("Input .ass files:");
    _lengthLabel->setText("Seq length: ");
    _lengthValue->setText("0");
    _remove->setStatusTip("Removes the selected entry from the list.");
    _remove->setText("Remove selection");
    _clear->setToolTip("Ctrl Command C");
    _clear->setStatusTip("Clears the list of input .ass files.");
    _clear->setText("Clear list");
    _clear->setShortcut(QKeySequence("Meta+Ctrl+C"));
    _browse->setToolTip("Command O");
    _browse->setStatusTip("File open dialog for .ass files.");
    _browse->setText("Browse ASS File(s)");
    _browse->setShortcut(QKeySequence("Ctrl+O"));

    QObject::connect(_browse, &QPushButton::clicked, _widget, [this]() {
        if (_events != nullptr) {
            _events->browse();
        }
    });
    QObject::connect(_clear, &QPushButton::clicked, _widget, [this]() {
        if (_events != nullptr) {
            _events->clear();
        }
    });
    QObject::connect(_remove, &QPushButton::clicked, _widget, [this]() {
        if (_events == nullptr) return;

        int n = _sequence->selectedItems().count();
        for (int i = 0; i < n; ++i) {
            QListWidgetItem* item = _sequence->selectedItems()[i];
            QString sequenceName = item->text();
            _events->remove(i, sequenceName);
        }
        _events->finishedRemoving();
    });
}

FileSequenceView::~FileSequenceView()
{
    if (_layout != nullptr) {
        delete _layout;
    }
}

QWidget* FileSequenceView::widget()
{
    return _widget;
}

FileSequenceView::Events* FileSequenceView::events()
{
    return _events;
}

void FileSequenceView::setEvents(Events* events)
{
    _events = events;
}

void FileSequenceView::setVersion(QString version)
{
    _version->setText(version);
}

void FileSequenceView::setLength(int length)
{
    _lengthValue->setText(QString::number(length));
}

void FileSequenceView::add(QString path)
{
    _sequence->addItem(path);
}

void FileSequenceView::clear()
{
    _sequence->clear();
}

void FileSequenceView::render()
{
    performLayout();
    setupStyleSheet();
}

void FileSequenceView::loadLayout(QJsonObject& config)
{
    QString key = _widget->objectName();
    if (config[key].isObject()) {
        QJsonObject config2 = config[key].toObject();
        LayoutLoad::fromJson(_layout, config2);
    } else {
        LayoutLoad::fromJson(_layout, config);
    }
}

void FileSequenceView::performLayout()
{
    _layout->width(_widget->width()).height(_widget->height());
    _layout->update();
}

void FileSequenceView::setupStyleSheet()
{
    _widget->setStyleSheet(
        "#fileSequence_browse {\n"
        "	color: rgb(200, 200, 40);\n"
        "	font-weight: bold;\n"
        "}\n"
        "\n"
        "#fileSequence_label,\n"
        "#fileSequence_sequenceLength_label,\n"
        "#fileSequence_sequenceLength_value {\n"
        "	background: rgb(72, 72, 72);\n"
        "	color: rgb(255, 255, 255);\n"
        "}\n"
        "\n");
}
