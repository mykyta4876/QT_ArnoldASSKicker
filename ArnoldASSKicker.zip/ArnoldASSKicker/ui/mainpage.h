#ifndef MAINPAGE_H
#define MAINPAGE_H

#include "filesequenceview.h"
#include "preferencesform.h"
#include "settings/settingsform.h"

#include <QJsonObject>
#include <QPlainTextEdit>
#include <QSplitter>

class MainPage
{
public:
    class Events {
    public:
        virtual ~Events() {}

        virtual void splitterMoved(int pos) = 0;
    };

    MainPage(QWidget* parent = nullptr);
    ~MainPage();

    QWidget* widget();
    Events* events();

    PreferencesForm& preferences() { return _preferences; }
    FileSequenceView& fileSequence() { return _fileSequence; }
    SettingsForm& settings() { return _settings; }

    void setEvents(Events* events);
    void setOutput(const QString& output);
    void appendOutput(const QString& output);
    void render();

    void loadLayout(QJsonObject& config);

    QString layoutDebugString();

private:
    QWidget* _widget;
    Events* _events;
    struct SplitterLayout {
        Layout* leftPane;
        Layout* rightPane;
    } _layout;

    QSplitter* _splitter;
    QWidget* _leftPane;
    QWidget* _rightPane;
    QPlainTextEdit* _renderOutput;

    PreferencesForm _preferences;
    FileSequenceView _fileSequence;
    SettingsForm _settings;

    QString _styleSheet;

    void performLayout();
    void setupStyleSheet();
    void splitterMoved(int pos);
};

#endif // MAINPAGE_H
