#include "mainpage.h"
#include "layoutload.h"
#include "style.h"

MainPage::MainPage(QWidget* parent) :
    _widget(new QWidget(parent)),
    _events(nullptr),
    _splitter(new QSplitter(_widget)),
    _leftPane(new QWidget(_splitter)),
    _rightPane(new QWidget(_splitter)),
    _renderOutput(new QPlainTextEdit(_rightPane)),
    _preferences(_rightPane),
    _fileSequence(_leftPane),
    _settings(_leftPane)
{
    _widget->setObjectName("centralWidget");
    _splitter->setObjectName("splitter");
    _leftPane->setObjectName("leftPane");
    _rightPane->setObjectName("rightPane");
    _renderOutput->setObjectName("renderOutput");

    _layout.leftPane = new Layout("leftPane", _leftPane);
    _layout.rightPane = new Layout("rightPane", _rightPane);

    _splitter->addWidget(_leftPane);
    _splitter->addWidget(_rightPane);
    _splitter->setFrameShape(QFrame::NoFrame);
    _splitter->setFrameShadow(QFrame::Plain);
    _splitter->setSizes(QList<int>({100, 100}));

    QFont font;
    font.setPointSize(9);
    _renderOutput->setFont(font);
    _renderOutput->setLineWrapMode(QPlainTextEdit::WidgetWidth);

    QObject::connect(_widget, &QObject::destroyed, _widget, [=]() {
        _widget = nullptr;
    });

    QObject::connect(_splitter, &QSplitter::splitterMoved, _splitter, [=](int pos, int) {
        splitterMoved(pos);
    });
}

MainPage::~MainPage()
{
    if (_widget != nullptr &&
        _widget->parentWidget() == nullptr) {
        delete _widget;
    }
}

QWidget* MainPage::widget()
{
    return _widget;
}

MainPage::Events* MainPage::events()
{
    return _events;
}

void MainPage::setEvents(Events* events)
{
    _events = events;
}

void MainPage::setOutput(const QString& output)
{
    _renderOutput->clear();
    appendOutput(output);
}

void MainPage::appendOutput(const QString& output)
{
    _renderOutput->appendPlainText(output);
}

void MainPage::render()
{
    performLayout();
    setupStyleSheet();

    _preferences.render();
    _fileSequence.render();
    _settings.render();

    //_content.widget()->setGeometry(0, 0, _widget->width(), _widget->height());
    //_content.render();
}

void MainPage::loadLayout(QJsonObject& config)
{
    QJsonObject leftPane = config["leftPane"].toObject();
    LayoutLoad::fromJson(_layout.leftPane, leftPane);

    QJsonObject rightPane = config["rightPane"].toObject();
    LayoutLoad::fromJson(_layout.rightPane, rightPane);

    _preferences.loadLayout(config);
    _fileSequence.loadLayout(config);
    _settings.loadLayout(config);
}

QString MainPage::layoutDebugString()
{
    QString str = _layout.leftPane->debugString();
    str += "\n\n" + _layout.rightPane->debugString();
    str += "\n\n" + _preferences.layoutDebugString();
    str += "\n\n" + _fileSequence.layoutDebugString();
    str += "\n\n" + _settings.layoutDebugString();
    return str;
}

void MainPage::performLayout()
{
    if (_widget->width() <= 800) {
        _splitter->setOrientation(Qt::Vertical);
    } else {
        _splitter->setOrientation(Qt::Horizontal);
    }

    _splitter->setGeometry(0, 0, _widget->width(), _widget->height());

    //_layout->width(_widget->width()).height(_widget->height());

    (*_layout.leftPane)
        .width(_leftPane->width())
        .height(_leftPane->height())
        .update();

    (*_layout.rightPane)
        .width(_rightPane->width())
        .height(_rightPane->height())
        .update();
}

void MainPage::setupStyleSheet()
{
    if (_styleSheet.isEmpty()) {
        _styleSheet = Style::qss();
        _widget->setStyleSheet(_styleSheet);
    }

    /*_widget->setStyleSheet(
        "#centralWidget {\n"
        "	background: rgb(0, 0, 0);\n"
        "}\n"
        "\n"
        "#splitter {\n"
        "	background: rgb(50, 50, 50);\n"
        "}\n"
        "\n"
        "#leftPane {\n"
        "	background: rgb(0, 200, 0);\n"
        "}\n"
        "\n"
        "#renderOutput {\n"
        "	background: rgb(0, 0, 200);\n"
        "}\n");*/
}

void MainPage::splitterMoved(int pos)
{
    if (_events != nullptr) {
        _events->splitterMoved(pos);
    }
}
