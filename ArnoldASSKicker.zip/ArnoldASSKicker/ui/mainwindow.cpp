#include "mainwindow.h"

#include <QApplication>
#include <QResizeEvent>
#include <QScreen>
#include <QStyle>

MainWindow::MainWindow() :
    _window(new Window(*this)),
    _events(nullptr),
    _viewport(new QWidget(_window)),
    _contents(nullptr),
    _pages(new QStackedWidget(_viewport)),
    _scrollX(new QScrollBar(_window)),
    _scrollY(new QScrollBar(_window)),
    _timer(new QTimer(_window)),
    _blockResizeEvent(false)
{
    _window->setObjectName("mainWindow");
    _viewport->setObjectName("mainWindow_viewport");
    _pages->setObjectName("mainWindow_pages");
    _scrollX->setObjectName("mainWindow_scrollX");
    _scrollY->setObjectName("mainWindow_scrollY");

    _scrollX->setOrientation(Qt::Horizontal);
    _scrollY->setOrientation(Qt::Vertical);

    detectScreenSize();
    performLayout();
    setupStyleSheet();
    showFrame();
    setContents(_pages);

    QObject::connect(_scrollX, &QScrollBar::valueChanged, _scrollX, [=](int value) {
        _layout.scrollXTo(value);
        render();
    });

    QObject::connect(_scrollY, &QScrollBar::valueChanged, _scrollY, [=](int value) {
        _layout.scrollYTo(value);
        render();
    });

    QObject::connect(_timer, &QTimer::timeout, _timer, [=]() {
        if (!_pendingResize.isValid()) return;

        performPendingResize();
        _timer->start(100);
    });
}

MainWindow::~MainWindow()
{
    delete _window;
}

QWidget* MainWindow::widget()
{
    return _window;
}

QWidget* MainWindow::contents()
{
    return _contents;
}

QString MainWindow::title()
{
    return _window->windowTitle();
}

MainWindow::Events* MainWindow::events()
{
    return _events;
}

bool MainWindow::isVisible()
{
    return _window->isVisible();
}

bool MainWindow::frameIsVisible()
{
    return _pages->frameShape() == QFrame::Box;
}

void MainWindow::show()
{
    _window->show();
}

void MainWindow::hide()
{
    _window->hide();
}

void MainWindow::showFrame()
{
    _pages->setFrameShape(QFrame::Box);
}

void MainWindow::hideFrame()
{
    _pages->setFrameShape(QFrame::NoFrame);
}

void MainWindow::setContents(QWidget* contents)
{
    if (_contents == contents) return;

    if (_contents != nullptr) {
        _contents->setParent(nullptr);
    }

    if (contents != nullptr) {
        contents->setParent(_viewport);
    }

    _contents = contents;
}

void MainWindow::setTitle(QString title)
{
    _window->setWindowTitle(title);
}

void MainWindow::setEvents(MainWindow::Events* events)
{
    _events = events;
}

void MainWindow::showPage(int page)
{
    if (page < 0 || _pages->count() <= page) return;

    _pages->setCurrentIndex(page);
}

void MainWindow::showPage(QWidget* page)
{
    if (_pages->indexOf(page) < 0) return;

    _pages->setCurrentWidget(page);
}

void MainWindow::addPage(QWidget* page)
{
    _pages->addWidget(page);
}

void MainWindow::autoSize()
{
    detectScreenSize();
    _layout.autoSize();
    render();

    int centerX = (_layout.screen().width() - _window->width()) / 2;
    _window->move(centerX, _window->y());
}

void MainWindow::resize(int width, int height)
{
    //qDebug() << "MainWindow::resize" << width << height;

    bool changed = _layout.resize(width, height);
    if (changed) render();

    //_window->blockSignals(true);
    //_window->resize(width, height);
    //_window->blockSignals(false);

    //_pages->resize(width, height);
}

void MainWindow::resizeViewport(int width, int height)
{
    bool changed = _layout.resizeViewport(width, height);
    if (changed) render();
}

void MainWindow::resizeContents(int width, int height)
{
    bool changed = _layout.resizeContents(width, height);
    if (changed) render();
}

void MainWindow::fixContentSize(bool fixed)
{
    _layout.fixContentSize(fixed);
}

void MainWindow::render()
{
    performLayout();
    setupStyleSheet();
}

void MainWindow::detectScreenSize()
{
    QRect screenSize = QApplication::primaryScreen()->availableGeometry();
    //int titleBarHeight = QApplication::style()->pixelMetric(QStyle::PM_TitleBarHeight);

    int width = screenSize.width();
    int height = screenSize.height();// - 2 * titleBarHeight;

    _layout.setScreenSize(width, height);
}

void MainWindow::performPendingResize()
{
    QSize size = _pendingResize;
    _pendingResize = QSize();

    int width = size.width();
    int height = size.height();

    //resizeContents(width, height);
    resize(width, height);

    width = _window->width();
    height = _window->height();

    if (_events != nullptr) {
        _events->resize(width, height);
    }
}

void MainWindow::performLayout()
{
    _blockResizeEvent = true;
    _window->blockSignals(true);
    _window->resize(_layout.window());
    _window->blockSignals(false);
    _blockResizeEvent = false;

    _viewport->setGeometry(_layout.viewport());

    if (_contents != nullptr) {
        _contents->setGeometry(_layout.contents());
    }

    Layout::ScrollBar scrollX = _layout.scrollX();
    Layout::ScrollBar scrollY = _layout.scrollY();

    _scrollX->blockSignals(true);
    _scrollX->setGeometry(scrollX.geometry);
    _scrollX->setVisible(scrollX.visible);
    _scrollX->setMinimum(scrollX.minimum);
    _scrollX->setMaximum(scrollX.maximum);
    _scrollX->setValue(scrollX.value);
    _scrollX->setPageStep(scrollX.pageStep);
    _scrollX->blockSignals(false);

    _scrollY->blockSignals(true);
    _scrollY->setGeometry(scrollY.geometry);
    _scrollY->setVisible(scrollY.visible);
    _scrollY->setMinimum(scrollY.minimum);
    _scrollY->setMaximum(scrollY.maximum);
    _scrollY->setValue(scrollY.value);
    _scrollY->setPageStep(scrollY.pageStep);
    _scrollY->blockSignals(false);
}

void MainWindow::setupStyleSheet()
{
    int borderRadiusX = _scrollX->height() / 2;
    int borderRadiusY = _scrollY->width() / 2;

    _window->setStyleSheet(
        "#mainWindow_scrollX:horizontal {\n"
        "	background: rgb(53, 53, 53);\n"
        "	width: 100%;\n"
        "}\n"
        "\n"
        "#mainWindow_scrollX::handle:horizontal {\n"
        "	background: rgb(181, 181, 181);\n"
        "	border-radius: " + QString::number(borderRadiusX) + "px;\n"
        "}\n"
        "\n"
        "#mainWindow_scrollX::add-line:horizontal {\n"
        "	width: 0;\n"
        "}\n"
        "\n"
        "#mainWindow_scrollX::sub-line:horizontal {\n"
        "	width: 0;\n"
        "}\n"
        "\n"
        "#mainWindow_scrollX::add-page:horizontal {\n"
        "	background: none;\n"
        "	width: 0;\n"
        "}\n"
        "\n"
        "#mainWindow_scrollX::sub-page:horizontal {\n"
        "	background: none;\n"
        "	width: 0;\n"
        "}\n"
        "\n"
        "#mainWindow_scrollX::left-button {\n"
        "	width: 0;\n"
        "}\n"
        "\n"
        "#mainWindow_scrollX::right-button {\n"
        "	width: 0;\n"
        "}\n"
        "\n"
        "#mainWindow_scrollY:vertical {\n"
        "	background: rgb(53, 53, 53);\n"
        "	height: 100%;\n"
        "}\n"
        "\n"
        "#mainWindow_scrollY::handle:vertical {\n"
        "	background: rgb(181, 181, 181);\n"
        "	border-radius: " + QString::number(borderRadiusY) + "px;\n"
        "}\n"
        "\n"
        "#mainWindow_scrollY::add-line:vertical {\n"
        "	height: 0;\n"
        "}\n"
        "\n"
        "#mainWindow_scrollY::sub-line:vertical {\n"
        "	height: 0;\n"
        "}\n"
        "\n"
        "#mainWindow_scrollY::add-page:vertical {\n"
        "	background: none;\n"
        "	height: 0;\n"
        "}\n"
        "\n"
        "#mainWindow_scrollY::sub-page:vertical {\n"
        "	background: none;\n"
        "	height: 0;\n"
        "}\n"
        "\n"
        "#mainWindow_scrollY::up-button {\n"
        "	height: 0;\n"
        "}\n"
        "\n"
        "#mainWindow_scrollY::down-button {\n"
        "	height: 0;\n"
        "}");
}

void MainWindow::resizeEvent(QResizeEvent* event)
{
    if (event == nullptr) return;
    if (_blockResizeEvent) return;

    //qDebug() << "MainWindow::resizeEvent" << event->size();

    _pendingResize = event->size();

    if (!_timer->isActive()) {
        performPendingResize();
        _timer->start(100);
    }
}

void MainWindow::wheelEvent(QWheelEvent* event)
{
    event->accept();

    int scrollUnitsX = event->angleDelta().x();
    int scrollUnitsY = event->angleDelta().y();

    _layout.scroll(scrollUnitsX, scrollUnitsY);
    render();
}
