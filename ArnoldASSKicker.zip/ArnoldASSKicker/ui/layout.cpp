#include "layout.h"

int operator +(Layout::Size& size, int x) { return size.computed() + x; }
int operator +(int x, Layout::Size& size) { return size.computed() + x; }
int operator +(Layout::Size& size1, Layout::Size& size2) {
    return size1.computed() + size2.computed();
}

int operator *(Layout::Size& size, int x) { return size.computed() * x; }
int operator *(int x, Layout::Size& size) { return size.computed() * x; }
int operator *(Layout::Size& size1, Layout::Size& size2) {
    return size1.computed() * size2.computed();
}

int operator -(Layout::Size& size, int x) { return size.computed() - x; }
int operator -(int x, Layout::Size& size) { return x - size.computed(); }
int operator -(Layout::Size& size1, Layout::Size& size2) {
    return size1.computed() - size2.computed();
}

int operator /(Layout::Size& size, int x) { return size.computed() / x; }
int operator /(int x, Layout::Size& size) { return x / size.computed(); }
int operator /(Layout::Size& size1, Layout::Size& size2) {
    return size1.computed() / size2.computed();
}

Layout::Layout(QWidget* widget)
{
    _widget = widget;
    _alignment = Center;
    _orientation = Horizontal;
    _flex = 0;
    _offsetX = 0;
    _offsetY = 0;
    _borderOverlap = false;
    _marginOverlap = false;
    _parent = nullptr;
}

Layout::Layout(QString name, QWidget* widget) :
    Layout(widget)
{
    _name = name;
}

Layout::~Layout()
{
    for (Layout* child : _children) {
        delete child;
    }
}

QString Layout::name()
{
    return _name;
}

QWidget* Layout::widget()
{
    return _widget;
}

Layout::Alignment Layout::alignment()
{
    return _alignment;
}

Layout::Orientation Layout::orientation()
{
    return _orientation;
}

int Layout::flex()
{
    return _flex;
}

int Layout::offsetX()
{
    return _offsetX;
}

int Layout::offsetY()
{
    return _offsetY;
}

Layout::Size Layout::width()
{
    return _width;
}

Layout::Size Layout::height()
{
    return _height;
}

Layout::Size Layout::contentWidth()
{
    return _contentWidth;
}

Layout::Size Layout::contentHeight()
{
    return _contentHeight;
}

Layout::SizeQuad Layout::padding()
{
    return _padding;
}

Layout::Size Layout::paddingTop()
{
    return _padding.top;
}

Layout::Size Layout::paddingBottom()
{
    return _padding.bottom;
}

Layout::Size Layout::paddingLeft()
{
    return _padding.left;
}

Layout::Size Layout::paddingRight()
{
    return _padding.right;
}

Layout::SizeQuad Layout::border()
{
    return _border;
}

Layout::Size Layout::borderTop()
{
    return _border.top;
}

Layout::Size Layout::borderBottom()
{
    return _border.bottom;
}

Layout::Size Layout::borderLeft()
{
    return _border.left;
}

Layout::Size Layout::borderRight()
{
    return _border.right;
}

bool Layout::borderOverlap()
{
    return _borderOverlap;
}

Layout::SizeQuad Layout::margin()
{
    return _margin;
}

Layout::Size Layout::marginTop()
{
    return _margin.top;
}

Layout::Size Layout::marginBottom()
{
    return _margin.bottom;
}

Layout::Size Layout::marginLeft()
{
    return _margin.left;
}

Layout::Size Layout::marginRight()
{
    return _margin.right;
}

bool Layout::marginOverlap()
{
    return _marginOverlap;
}

Layout* Layout::root()
{
    Layout* layout = this;
    while (layout->parent() != nullptr) {
        layout = layout->parent();
    }
    return layout;
}

Layout* Layout::parent()
{
    return _parent;
}

Layout* Layout::child(int index)
{
    if (index < 0 || numChildren() <= index) return nullptr;

    return _children[index];
}

int Layout::numChildren()
{
    return _children.length();
}

Layout* Layout::find(QString name, bool recurse)
{
    for (Layout* child : _children) {
        if (child->name() == name) {
            return child;
        }

        if (!recurse) continue;

        Layout* descendant = child->find(name);
        if (descendant != nullptr) {
            return descendant;
        }
    }

    return nullptr;
}

Layout* Layout::findChild(QString name)
{
    return find(name, false);
}

QList<Layout*> Layout::findAll(QString name, bool recurse)
{
    QList<Layout*> matches;

    for (Layout* child : _children) {
        if (child->name() == name) {
            matches.append(child);
        }

        if (recurse) {
            matches.append(child->findAll(name));
        }
    }

    return matches;
}

QList<Layout*> Layout::findChildren(QString name)
{
    return findAll(name, false);
}

Layout& Layout::name(QString name)
{
    _name = name;
    return *this;
}

Layout& Layout::widget(QWidget* widget)
{
    _widget = widget;
    return *this;
}

Layout& Layout::alignment(Layout::Alignment alignment)
{
    _alignment = alignment;
    return *this;
}

Layout& Layout::orientation(Layout::Orientation orientation)
{
    _orientation = orientation;
    return *this;
}

Layout& Layout::flex(int flex)
{
    _flex = flex;
    return *this;
}

Layout& Layout::offset(int x, int y)
{
    _offsetX = x;
    _offsetY = y;
    return *this;
}

Layout& Layout::offsetX(int x)
{
    _offsetX = x;
    return *this;
}

Layout& Layout::offsetY(int y)
{
    _offsetY = y;
    return *this;
}

Layout& Layout::resize(Layout::Size width, Layout::Size height)
{
    _width = width;
    _height = height;
    return *this;
}

Layout& Layout::width(Layout::Size width)
{
    _width = width;
    return *this;
}

Layout& Layout::height(Layout::Size height)
{
    _height = height;
    return *this;
}

Layout& Layout::content(Layout::Size width, Layout::Size height)
{
    _contentWidth = width;
    _contentHeight = height;
    return *this;
}

Layout& Layout::contentWidth(Layout::Size width)
{
    _contentWidth = width;
    return *this;
}

Layout& Layout::contentHeight(Layout::Size height)
{
    _contentHeight = height;
    return *this;
}

Layout& Layout::padding(Layout::SizeQuad width)
{
    _padding = width;
    return *this;
}

Layout& Layout::padding(Layout::Size topBottom, Layout::Size rightLeft)
{
    _padding.top = topBottom;
    _padding.right = rightLeft;
    _padding.bottom = topBottom;
    _padding.left = rightLeft;
    return *this;
}

Layout& Layout::padding(Layout::Size top, Layout::Size right, Layout::Size bottom, Layout::Size left)
{
    _padding.top = top;
    _padding.right = right;
    _padding.bottom = bottom;
    _padding.left = left;
    return *this;
}

Layout& Layout::paddingTop(Layout::Size width)
{
    _padding.top = width;
    return *this;
}

Layout& Layout::paddingBottom(Layout::Size width)
{
    _padding.bottom = width;
    return *this;
}

Layout& Layout::paddingLeft(Layout::Size width)
{
    _padding.left = width;
    return *this;
}

Layout& Layout::paddingRight(Layout::Size width)
{
    _padding.right = width;
    return *this;
}

Layout& Layout::border(Layout::SizeQuad width)
{
    _border = width;
    return *this;
}

Layout& Layout::border(Layout::Size topBottom, Layout::Size rightLeft)
{
    _border.top = topBottom;
    _border.right = rightLeft;
    _border.bottom = topBottom;
    _border.left = rightLeft;
    return *this;
}

Layout& Layout::border(Layout::Size top, Layout::Size right, Layout::Size bottom, Layout::Size left)
{
    _border.top = top;
    _border.right = right;
    _border.bottom = bottom;
    _border.left = left;
    return *this;
}

Layout& Layout::borderTop(Layout::Size width)
{
    _border.top = width;
    return *this;
}

Layout& Layout::borderBottom(Layout::Size width)
{
    _border.bottom = width;
    return *this;
}

Layout& Layout::borderLeft(Layout::Size width)
{
    _border.left = width;
    return *this;
}

Layout& Layout::borderRight(Layout::Size width)
{
    _border.right = width;
    return *this;
}

Layout& Layout::borderOverlap(bool flag)
{
    _borderOverlap = flag;
    return *this;
}

Layout& Layout::margin(Layout::SizeQuad width)
{
    _margin = width;
    return *this;
}

Layout& Layout::margin(Layout::Size topBottom, Layout::Size rightLeft)
{
    _margin.top = topBottom;
    _margin.right = rightLeft;
    _margin.bottom = topBottom;
    _margin.left = rightLeft;
    return *this;
}

Layout& Layout::margin(Layout::Size top, Layout::Size right, Layout::Size bottom, Layout::Size left)
{
    _margin.top = top;
    _margin.right = right;
    _margin.bottom = bottom;
    _margin.left = left;
    return *this;
}

Layout& Layout::marginTop(Layout::Size width)
{
    _margin.top = width;
    return *this;
}

Layout& Layout::marginBottom(Layout::Size width)
{
    _margin.bottom = width;
    return *this;
}

Layout& Layout::marginLeft(Layout::Size width)
{
    _margin.left = width;
    return *this;
}

Layout& Layout::marginRight(Layout::Size width)
{
    _margin.right = width;
    return *this;
}

Layout& Layout::marginOverlap(bool flag)
{
    _marginOverlap = flag;
    return *this;
}

Layout& Layout::parent(Layout* layout)
{
    if (layout == nullptr) return *this;
    if (_parent == layout) return *this;

    layout->child(this);
    return *this;
}

Layout& Layout::child(Layout* layout)
{
    if (layout == nullptr) return *this;

    child(numChildren(), layout);
    return *this;
}

Layout& Layout::child(Layout& layout)
{
    child(&layout);
    return *this;
}

Layout& Layout::child(int index, Layout* layout)
{
    if (layout == nullptr) return *this;
    if (_children.contains(layout)) return *this;
    if (index < 0 || numChildren() < index) return *this;

    layout->removeParent();
    layout->_parent = this;

    if (index == numChildren()) {
        _children.append(layout);
    } else {
        _children.insert(index, layout);
    }

    return *this;
}

Layout& Layout::children(QList<Layout*>& layouts)
{
    for (Layout* layout : layouts) {
        child(layout);
    }

    return *this;
}

Layout& Layout::children(int index, QList<Layout*>& layouts)
{
    for (int i = layouts.size() - 1; i >= 0; i--) {
        child(index, layouts[i]);
    }

    return *this;
}

Layout& Layout::removeParent(bool delete_)
{
    if (_parent == nullptr) return *this;

    _parent->_children.removeOne(this);

    if (delete_) {
        delete _parent;
    }

    _parent = nullptr;
    return *this;
}

Layout& Layout::removeChild(int index, bool delete_)
{
    if (index < 0 || numChildren() <= index) return *this;

    Layout* child = _children[index];
    _children.removeAt(index);

    if (child == nullptr) return *this;

    child->_parent = nullptr;

    if (delete_) {
        delete child;
    }

    return *this;
}

Layout& Layout::clearChildren(bool delete_)
{
    for (Layout* child : _children) {
        if (child == nullptr) continue;

        child->_parent = nullptr;

        if (delete_) {
            delete child;
        }
    }

    _children.clear();
    return *this;
}

void Layout::update()
{
    //if (_name == "leftColumn") {
    //    _name = "leftColumn";
    //}

    if (_parent == nullptr) {
        computeRoot();
    }

    if (_widget != nullptr) {
        QRect rect = computeGeometry();
        _widget->setGeometry(rect);
    }

    Layout* previousChild = nullptr;

    for (Layout* child : _children) {
        computeBox(*child);

        if (previousChild != nullptr) {
            alignChild(*child, *previousChild);
        } else {
            alignChild(*child);
        }

        previousChild = child;
    }

    computeFlex();

    for (Layout* child : _children) {
        child->update();
    }
}

QString Layout::debugString(int indent)
{
    QString indentStr = QString('\t').repeated(indent);

    QString debugStr;

    if (!_name.isEmpty()) {
        debugStr += indentStr + _name + '\n' + indentStr + "----------\n";
    }

    if (_widget != nullptr && !_widget->objectName().isEmpty()) {
        debugStr += indentStr + "widget: " + _widget->objectName() + '\n';
    }

    if (_widget != nullptr) {
        QRect rect = computeGeometry();
        debugStr += indentStr + "geometry: " +
            '(' + QString::number(rect.x()) + ", " + QString::number(rect.y()) + ") " +
            QString::number(rect.width()) + " x " + QString::number(rect.height()) + '\n';
    }

    debugStr += indentStr + "offsetX: " + QString::number(_offsetX);
    debugStr += '\n' + indentStr + "offsetY: " + QString::number(_offsetY);
    debugStr += '\n' + indentStr + "computed width: " + QString::number(_width);
    debugStr += '\n' + indentStr + "computed height: " + QString::number(_height);

    debugStr += '\n' + indentStr + "align: " + (
        _alignment == Top ? "top" :
        _alignment == Bottom ? "bottom" :
        _alignment == Left ? "left" :
        _alignment == Right ? "right" :
        _alignment == Center ? "center" :
        "unknown");

    debugStr += '\n' + indentStr + "orientation: " + (
        _orientation == Horizontal ? "horizontal" :
        _orientation == Vertical ? "vertical" :
        "unknown");

    if (_flex != 0) {
        debugStr += '\n' + indentStr + "flex: " + QString::number(_flex);
    }

    if (_borderOverlap) {
        debugStr += '\n' + indentStr + "border overlap: true";
    }

    if (_marginOverlap) {
        debugStr += '\n' + indentStr + "margin overlap: true";
    }

    debugStr += debugString(_width, "width", indentStr);
    debugStr += debugString(_height, "height", indentStr);
    debugStr += debugString(_contentWidth, "contentWidth", indentStr);
    debugStr += debugString(_contentHeight, "contentHeight", indentStr);

    debugStr += debugString(_padding, "padding", indentStr);
    debugStr += debugString(_border, "border", indentStr);
    debugStr += debugString(_margin, "margin", indentStr);

    for (Layout* child : _children) {
        debugStr += "\n\n" + child->debugString(indent + 1);
    }

    return debugStr;
}

void Layout::computeRoot()
{
    _width = _width.value;
    _height = _height.value;

    computeSizeQuad(_padding, _width, _height);
    computeSizeQuad(_border, _width, _height);
}

#include <QDebug>
QRect Layout::computeGeometry()
{
    //Offset is not correct if parent layout is not bound to parent widget
    //What should the offset be?
    //From parent layout, find first common ancestor widget
    //Sum the offsets while traversing, to get parent layout offset relative to common ancestor widget
    //Add this offset to parent layout offset, to get offset relative to ancestor
    //If common ancestor is direct parent, do nothing
    //Else map from ancestor position to direct parent position
    //setGeometry with this computed position

    //if (_widget == nullptr) return QRect();

    if (_parent == nullptr) {
        return QRect(_widget->x(), _widget->y(), _width, _height);
    }

    QList<QWidget*> ancestorWidgets;

    QWidget* parent = _widget->parentWidget();
    while (parent != nullptr) {
        ancestorWidgets.append(parent);
        parent = parent->parentWidget();
    }

    int offsetX = _offsetX;
    int offsetY = _offsetY;

    Layout* ancestorLayout = _parent;
    while (ancestorLayout != nullptr) {
        if (ancestorWidgets.contains(ancestorLayout->_widget)) break;

        offsetX += ancestorLayout->_offsetX;
        offsetY += ancestorLayout->_offsetY;

        ancestorLayout = ancestorLayout->_parent;
    }

    if (ancestorLayout == nullptr ||
        ancestorLayout->_widget == nullptr ||
        ancestorLayout->_widget == _widget ||
        ancestorLayout->_widget == _widget->parentWidget()) {

        return QRect(offsetX, offsetY, _width, _height);
        //_widget->setGeometry(_offsetX, _offsetY, _width, _height);
        //qDebug() << _widget->objectName() << _widget->geometry();
        //return;
    }

    QPoint offset = _widget->parentWidget()->mapFrom(
        ancestorLayout->_widget,
        QPoint(offsetX, offsetY));

    return QRect(offset.x(), offset.y(), _width, _height);
    //_widget->setGeometry(offset.x(), offset.y(), _width, _height);
    //qDebug() << _widget->objectName() << _widget->geometry();
}

void Layout::computeSize(Layout::Size& size, int widthOrHeight)
{
    if (size.unit == Percent) {
        size = size.value * widthOrHeight / 100;

    } else if (size.unit == Pixels) {
        size = size.value;

    } else {
        size = 0;
    }
}

void Layout::computeSizeQuad(Layout::SizeQuad& size, int width, int height)
{
    computeSize(size.top, height);
    computeSize(size.bottom, height);
    computeSize(size.left, width);
    computeSize(size.right, width);
}

void Layout::computeBox(Layout& child)
{
    //Margin
    computeSizeQuad(child._margin, _width, _height);

    //Width or content box width

    int width = 0;
    int availableWidth = _width - _border.left - _border.right - _padding.left - _padding.right;
    bool useContentBoxForWidth = false;

    if (!child._width.isNull()) {
        if (child._width.unit == Percent) {
            width = child._width.value * availableWidth / 100;
        } else {
            width = child._width.value;
        }

        child._width = width;

    } else if (!child._contentWidth.isNull()) {
        if (child._contentWidth.unit == Percent) {
            width = child._contentWidth.value * availableWidth / 100;
        } else {
            width = child._contentWidth.value;
        }

        child._contentWidth = width;
        useContentBoxForWidth = true;

    } else {
        child._width = 0;
        child._contentWidth = 0;
    }

    //Height or content box height

    int height = 0;
    int availableHeight = _height - _border.top - _border.bottom - _padding.top - _padding.bottom;
    bool useContentBoxForHeight = false;

    if (!child._height.isNull()) {
        if (child._height.unit == Percent) {
            height = child._height.value * availableHeight / 100;
        } else {
            height = child._height.value;
        }

        child._height = height;

    } else if (!child._contentHeight.isNull()) {
        if (child._contentHeight.unit == Percent) {
            height = child._contentHeight.value * availableHeight / 100;
        } else {
            height = child._contentHeight.value;
        }

        child._contentHeight = height;
        useContentBoxForHeight = true;

    } else {
        child._height = 0;
        child._contentHeight = 0;
    }

    //Width or content box width

    if (useContentBoxForWidth) {
        if (child._contentWidth.unit == Aspect) {
            child._contentWidth = child._contentWidth.value * height / 100;
        }

    } else if (child._width.unit == Aspect) {
        child._width = child._width.value * height / 100;
    }

    //Height or content box height

    if (useContentBoxForHeight) {
        if (child._contentHeight.unit == Aspect) {
            child._contentHeight = child._contentHeight.value * width / 100;
        }

    } else if (child._height.unit == Aspect) {
        child._height = child._height.value * width / 100;
    }

    //Padding and border

    computeSizeQuad(child._padding, width, height);
    computeSizeQuad(child._border, width, height);

    //Width or content box width

    if (useContentBoxForWidth) {
        child._width = width
            + child._border.left + child._border.right
            + child._padding.left + child._padding.right;

    } else {
        child._contentWidth = width
            - child._border.left - child._border.right
            - child._padding.left - child._padding.right;
    }

    //Height or content box height

    if (useContentBoxForHeight) {
        child._height = height
            + child._border.top + child._border.bottom
            + child._padding.top + child._padding.bottom;

    } else {
        child._contentHeight = height
            - child._border.top - child._border.bottom
            - child._padding.top - child._padding.bottom;
    }
}

void Layout::alignChild(Layout& child)
{
    if (_orientation == Horizontal) {
        alignLeft(child);

        if (child._alignment == Top) {
            alignTop(child);

        } else if (child._alignment == Bottom) {
            alignBottom(child);

        } else {
            child._offsetY = (_height - child._height) / 2;
        }

    } else {
        alignTop(child);

        if (child._alignment == Left) {
            alignLeft(child);

        } else if (child._alignment == Right) {
            alignRight(child);

        } else {
            child._offsetX = (_width - child._width) / 2;
        }
    }
}

void Layout::alignTop(Layout& child)
{
    int y = _border.top + _padding.top + child._margin.top;

    if (child._marginOverlap) {
        if (child._margin.top > _padding.top) {
            y -= _padding.top;
        } else {
            y -= child._margin.top;
        }
    }

    bool hasPadding = _padding.top > 0;
    bool childHasMargin = child._margin.top > 0;

    if (child._borderOverlap && !hasPadding && !childHasMargin) {
        if (child._border.top > _border.top) {
            y -= _border.top;
        } else {
            y -= child._border.top;
        }
    }

    child._offsetY = y;
}

void Layout::alignBottom(Layout& child)
{
    int y = _height
        - _border.bottom - _padding.bottom
        - child._margin.bottom - child._height;

    if (child._marginOverlap) {
        if (child._margin.bottom > _padding.bottom) {
            y += _padding.bottom;
        } else {
            y += child._margin.bottom;
        }
    }

    bool hasPadding = _padding.bottom > 0;
    bool childHasMargin = child._margin.bottom > 0;

    if (child._borderOverlap && !hasPadding && !childHasMargin) {
        if (child._border.bottom > _border.bottom) {
            y += _border.bottom;
        } else {
            y += child._border.bottom;
        }
    }

    child._offsetY = y;
}

void Layout::alignLeft(Layout& child)
{
    int x = _border.left + _padding.left + child._margin.left;

    if (child._marginOverlap) {
        if (child._margin.left > _padding.left) {
            x -= _padding.left;
        } else {
            x -= child._margin.left;
        }
    }

    bool hasPadding = _padding.left > 0;
    bool childHasMargin = child._margin.left > 0;

    if (child._borderOverlap && !hasPadding && !childHasMargin) {
        if (child._border.left > _border.left) {
            x -= _border.left;
        } else {
            x -= child._border.left;
        }
    }

    child._offsetX = x;
}

void Layout::alignRight(Layout& child)
{
    int x = _width
        - _border.right - _padding.right
        - child._margin.right - child._width;

    if (child._marginOverlap) {
        if (child._margin.right > _padding.right) {
            x += _padding.right;
        } else {
            x += child._margin.right;
        }
    }

    bool hasPadding = _padding.right > 0;
    bool childHasMargin = child._margin.right > 0;

    if (child._borderOverlap && !hasPadding && !childHasMargin) {
        if (child._border.right > _border.right) {
            x += _border.right;
        } else {
            x += child._border.right;
        }
    }

    child._offsetX = x;
}

void Layout::alignChild(Layout& child, Layout& previousChild)
{
    if (_orientation == Horizontal) {
        alignLeft(child, previousChild);

        if (child._alignment == Top) {
            alignTop(child);

        } else if (child._alignment == Bottom) {
            alignBottom(child);

        } else {
            child._offsetY = (_height - child._height) / 2;
        }

    } else {
        alignTop(child, previousChild);

        if (child._alignment == Left) {
            alignLeft(child);

        } else if (child._alignment == Right) {
            alignRight(child);

        } else {
            child._offsetX = (_width - child._width) / 2;
        }
    }
}

void Layout::alignTop(Layout& child, Layout& previousChild)
{
    int y = previousChild._offsetY + previousChild._height +
        previousChild._margin.bottom + child._margin.top;

    if (child._marginOverlap && previousChild._marginOverlap) {
        if (child._margin.top > previousChild._margin.bottom) {
            y -= previousChild._margin.bottom;
        } else {
            y -= child._margin.top;
        }
    }

    bool childHasMargin = child._margin.top > 0;
    bool previousHasMargin = previousChild._margin.bottom > 0;

    if (child._borderOverlap && previousChild._borderOverlap &&
        !childHasMargin && !previousHasMargin) {

        if (child._border.top > previousChild._border.bottom) {
            y -= previousChild._border.bottom;
        } else {
            y -= child._border.top;
        }
    }

    child._offsetY = y;
}

void Layout::alignLeft(Layout& child, Layout& previousChild)
{
    int x = previousChild._offsetX + previousChild._width +
        previousChild._margin.right + child._margin.left;

    if (child._marginOverlap && previousChild._marginOverlap) {
        if (child._margin.left > previousChild._margin.right) {
            x -= previousChild._margin.right;
        } else {
            x -= child._margin.left;
        }
    }

    bool childHasMargin = child._margin.left > 0;
    bool previousHasMargin = previousChild._margin.right > 0;

    if (child._borderOverlap && previousChild._borderOverlap &&
        !childHasMargin && !previousHasMargin) {

        if (child._border.left > previousChild._border.right) {
            x -= previousChild._border.right;
        } else {
            x -= child._border.left;
        }
    }

    child._offsetX = x;
}

void Layout::computeFlex()
{
    if (numChildren() == 0) return;

    Layout* lastChild = child(numChildren() - 1);

    int totalFlex = 0;
    for (Layout* child : _children) {
        totalFlex += child->_flex;
    }

    if (totalFlex == 0) return;

    if (_orientation == Horizontal) {
        int x = lastChild->_offsetX;
        alignRight(*lastChild);

        int endOffset = lastChild->_offsetX + lastChild->_width;
        lastChild->_offsetX = x;

        int availableSpace = endOffset - (lastChild->_offsetX + lastChild->_width);
        int spaceUsed = 0;

        if (availableSpace <= 0) return;

        for (Layout* child : _children) {
            int growth = child->_flex * availableSpace / totalFlex;

            child->_offsetX = child->_offsetX + spaceUsed;
            child->_width = child->_width + growth;
            child->_contentWidth = child->_contentWidth + growth;

            spaceUsed += growth;
        }

        availableSpace -= spaceUsed;
        lastChild->_width = lastChild->_width + availableSpace;
        lastChild->_contentWidth = lastChild->_contentWidth + availableSpace;

    } else {
        int y = lastChild->_offsetY;
        alignBottom(*lastChild);

        int endOffset = lastChild->_offsetY + lastChild->_height;
        lastChild->_offsetY = y;

        int availableSpace = endOffset - (lastChild->_offsetY + lastChild->_height);
        int spaceUsed = 0;

        if (availableSpace <= 0) return;

        for (Layout* child : _children) {
            int growth = child->_flex * availableSpace / totalFlex;

            child->_offsetY = child->_offsetY + spaceUsed;
            child->_height = child->_height + growth;
            child->_contentHeight = child->_contentHeight + growth;

            spaceUsed += growth;
        }

        availableSpace -= spaceUsed;
        lastChild->_height = lastChild->_height + availableSpace;
        lastChild->_contentHeight = lastChild->_contentHeight + availableSpace;
    }
}

QString Layout::debugString(Layout::Size& size, QString name, QString indentStr)
{
    if (size.value == 0) return QString();

    return '\n' + indentStr + name + ": " + QString::number(size.value) + (
        size.unit == Percent ? "%" :
        size.unit == Pixels ? "px" : "");
}

QString Layout::debugString(Layout::SizeQuad& size, QString name, QString indentStr)
{
    return debugString(size.top, name + " top", indentStr) +
        debugString(size.bottom, name + " bottom", indentStr) +
        debugString(size.left, name + " left", indentStr) +
        debugString(size.right, name + " right", indentStr);
}
