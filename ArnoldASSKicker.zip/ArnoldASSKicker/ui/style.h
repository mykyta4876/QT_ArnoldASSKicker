#ifndef STYLE_H
#define STYLE_H

#include <QString>

class Style
{
public:
    static QString qss();
};

#endif // STYLE_H
