#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "mainwindowlayout.h"

#include <QScrollBar>
#include <QStackedWidget>
#include <QTimer>

class MainWindow
{
public:
    class Events {
    public:
        virtual ~Events() {}

        virtual void resize(int width, int height) = 0;
    };

    MainWindow();
    ~MainWindow();

    QWidget* widget();
    QWidget* contents();
    QString title();
    Events* events();

    bool isVisible();
    bool frameIsVisible();

    void show();
    void hide();
    void showFrame();
    void hideFrame();

    void setContents(QWidget* contents);
    void setTitle(QString title);
    void setEvents(Events* events);

    void showPage(int page);
    void showPage(QWidget* page);
    void addPage(QWidget* page);

    void autoSize();
    void resize(int width, int height);
    void resizeViewport(int width, int height);
    void resizeContents(int width, int height);
    void fixContentSize(bool fixed = true);

    void render();

private:
    using Layout = MainWindowLayout;

    struct Window : public QWidget {
        MainWindow& _ref;
        Window(MainWindow& ref) : _ref(ref) {}
        void resizeEvent(QResizeEvent* e) { _ref.resizeEvent(e); }
    };

    Window* _window;
    Events* _events;
    QWidget* _viewport;
    QWidget* _contents;
    QStackedWidget* _pages;
    QScrollBar* _scrollX;
    QScrollBar* _scrollY;

    QTimer* _timer;
    QSize _pendingResize;
    bool _blockResizeEvent;

    Layout _layout;

    void detectScreenSize();
    void performPendingResize();
    void performLayout();
    void setupStyleSheet();

    void resizeEvent(QResizeEvent* event);
    void wheelEvent(QWheelEvent* event);
};

#endif // MAINWINDOW_H
