#ifndef MAINWINDOWLAYOUT_H
#define MAINWINDOWLAYOUT_H

#include <QRect>

class MainWindowLayout {
public:
    enum Region {
        None,
        Window,
        Viewport,
        Contents
    };

    struct ScrollBar {
        QRect geometry;
        bool visible;
        int minimum;
        int maximum;
        int value;
        int pageStep;
        int scrollUnitsPerPixel;
    };

    struct Limits {
        QSize screenMin;
        QSize screenDefault;
        QSize windowMin;
        QSize windowMax;
        QSize windowDefault;
        int scrollBarWidthMin;
        int scrollBarWidthMax;
        int scrollBarWidthDefault;
        int scrollUnitsPerPixelDefault;
    };

    MainWindowLayout();
    MainWindowLayout(int screenWidth, int screenHeight);

    QSize screen();
    QSize window();
    QRect viewport();
    QRect contents();
    ScrollBar scrollX();
    ScrollBar scrollY();
    Limits limits();

    void setScreenSize(int width, int height);
    void autoSize();

    bool resize(int width, int height);
    bool resizeViewport(int width, int height);
    bool resizeContents(int width, int height);
    void fixContentSize(bool fixed = true);

    void setScrollBarWidth(int width);
    void setScrollUnitsPerPixel(int scrollUnits);
    void setScrollUnitsPerPixel(int scrollUnitsX, int scrollUnitsY);

    void scroll(int scrollUnitsX, int scrollUnitsY);
    void scrollX(int scrollUnits);
    void scrollY(int scrollUnits);

    void scrollTo(int scrollValueX, int scrollValueY);
    void scrollXTo(int scrollValue);
    void scrollYTo(int scrollValue);

private:
    QSize _screen;
    QSize _window;
    QRect _viewport;
    QRect _contents;
    ScrollBar _scrollX;
    ScrollBar _scrollY;
    Region _resizeTarget;
    bool _contentSizeFixed;

    bool compute();
    void clampToWindow();
    void clampToViewport();
    void clampToContents();
};

#endif // MAINWINDOWLAYOUT_H
