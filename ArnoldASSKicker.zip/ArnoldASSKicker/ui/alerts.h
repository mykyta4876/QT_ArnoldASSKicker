#ifndef ALERTS_H
#define ALERTS_H

#include <QString>

class Alerts
{
public:
    static void exec(QString msg, QString info);
    static void renderFinished(QString msg = "");
    static void renderStopped(QString msg = "");
    static void launchKickFailed(QString msg = "");
    static void noKickPath(QString msg = "");
    static void noFilesSelected(QString msg = "");
};

#endif // ALERTS_H
