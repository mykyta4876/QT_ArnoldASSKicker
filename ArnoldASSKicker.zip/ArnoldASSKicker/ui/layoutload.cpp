#include "layoutload.h"

#include <QJsonDocument>

namespace LayoutLoad
{

QJsonObject toJson(Layout* layout)
{
    QJsonObject config;
    toJson(layout, config);
    return config;
}

void toJson(Layout* layout, QJsonObject& /*config*/)
{
    if (layout == nullptr) return;
    //TODO
}

Layout* fromJson(QString& json)
{
    Layout* layout = new Layout();
    fromJson(layout, json);
    return layout;
}

Layout* fromJson(QJsonObject& config)
{
    Layout* layout = new Layout();
    fromJson(layout, config);
    return layout;
}

void fromJson(Layout* layout, QString& json)
{
    QJsonDocument doc = QJsonDocument::fromJson(json.toLatin1());
    if (!doc.isObject()) return;

    QJsonObject config = doc.object();
    fromJson(layout, config);
}

void fromJson(Layout* layout, QJsonObject& config)
{
    if (layout == nullptr) return;

    //QWidget* widget = layout->widget();
    //if (widget == nullptr) return;

    QJsonArray tree = config["layout"].toArray();
    buildTree(tree, layout);

    QStringList keys = config.keys();
    for (const QString& key : keys) {
        if (key == "layout") continue;
        if (!config[key].isObject()) continue;

        Layout* nextLayout = nullptr;
        if (key == layout->name()) {
            nextLayout = layout;
        } else {
            nextLayout = layout->find(key);
        }
        if (nextLayout == nullptr) continue;

        QJsonObject nextConfig = config[key].toObject();
        configureLayout(nextLayout, nextConfig);
    }
}

QWidget* topLevelWidget(Layout* layout)
{
    if (layout == nullptr) return nullptr;

    QWidget* widget = layout->widget();
    if (widget != nullptr) return widget->window();

    int n = layout->numChildren();
    for (int i = 0; i < n; i++) {
        Layout* child = layout->child(i);
        QWidget* widget = topLevelWidget(child);
        if (widget != nullptr) return widget;
    }
    return nullptr;
}

void buildTree(QJsonArray& tree, Layout* layout, QWidget* widget)
{
    if (widget == nullptr) {
        widget = topLevelWidget(layout);
    }
    if (widget == nullptr) return;

    Layout* root = layout->root();

    for (int i = 0; i < tree.size(); i++) {
        QString name = tree[i].toString();
        if (name.isEmpty()) continue;

        QString objectName;
        QStringList sl = name.split('#');
        if (sl.size() >= 2) {
            name = sl[0];
            objectName = sl[1];
        } else {
            name = objectName = sl[0];
        }
        if (name.isEmpty()) {
            name = objectName;
        }

        Layout* childLayout = root->find(name);
        if (childLayout == nullptr) {
            childLayout = new Layout(name);
        }
        //TODO: detect cycles?

        layout->child(childLayout);

        QWidget* childWidget = widget->findChild<QWidget*>(objectName);
        childLayout->widget(childWidget);

        if (i + 1 == tree.size()) continue;
        if (!tree[i + 1].isArray()) continue;

        i++;
        QJsonArray subTree = tree[i].toArray();
        buildTree(subTree, childLayout, widget);
    }
}

Layout::Size getSize(QJsonValue value)
{
    if (value.isDouble()) {
        return Layout::Size(value.toInt());
    }
    if (!value.isString()) return Layout::Size();

    QString input = value.toString();
    QString numberPart = input;
    QChar nonDigit;

    for (int i = 0; i < input.length(); i++) {
        if (input[i].isDigit()) continue;
        if (input[i].isSpace()) continue;

        nonDigit = input[i];
        numberPart = input.left(i);
        break;
    }

    bool ok = false;
    int intValue = numberPart.toInt(&ok);
    if (!ok) {
        intValue = 0;
    }

    Layout::Unit unit = Layout::Pixels;
    if (nonDigit == '%') {
        unit = Layout::Percent;
    } else if (!nonDigit.isNull() && nonDigit.toLower() != 'p') {
        unit = Layout::Aspect;
    }
    return Layout::Size(intValue, unit);
}

void configureLayout(Layout* layout, QJsonObject& config)
{
    QString alignment = config["alignment"].toString();
    alignment = alignment.toLower();
    if (alignment == "top") {
        layout->alignment(Layout::Top);
    }
    if (alignment == "left") {
        layout->alignment(Layout::Left);
    }
    if (alignment == "center") {
        layout->alignment(Layout::Center);
    }
    if (alignment == "right") {
        layout->alignment(Layout::Right);
    }
    if (alignment == "bottom") {
        layout->alignment(Layout::Bottom);
    }

    QString orientation = config["orientation"].toString();
    orientation = orientation.toLower();
    if (orientation == "horizontal") {
        layout->orientation(Layout::Horizontal);
    }
    if (orientation == "vertical") {
        layout->orientation(Layout::Vertical);
    }

    if (config["flex"].isDouble()) {
        int flex = config["flex"].toInt();
        layout->flex(flex);
    }

    QJsonObject offset = config["offset"].toObject();
    if (offset["x"].isDouble()) {
        int x = offset["x"].toInt();
        layout->offsetX(x);
    }
    if (offset["y"].isDouble()) {
        int y = offset["y"].toInt();
        layout->offsetY(y);
    }

    Layout::Size width(getSize(config["width"]));
    if (!width.isNull()) {
        layout->width(width);
    }

    Layout::Size height(getSize(config["height"]));
    if (!height.isNull()) {
        layout->height(height);
    }

    Layout::Size contentWidth(getSize(config["contentWidth"]));
    if (!contentWidth.isNull()) {
        layout->contentWidth(contentWidth);
    }

    Layout::Size contentHeight(getSize(config["contentHeight"]));
    if (!contentHeight.isNull()) {
        layout->contentHeight(contentHeight);
    }

    QJsonObject padding = config["padding"].toObject();
    Layout::Size paddingTop(getSize(padding["top"]));
    if (!paddingTop.isNull()) {
        layout->paddingTop(paddingTop);
    }
    Layout::Size paddingBottom(getSize(padding["bottom"]));
    if (!paddingBottom.isNull()) {
        layout->paddingBottom(paddingBottom);
    }
    Layout::Size paddingLeft(getSize(padding["left"]));
    if (!paddingLeft.isNull()) {
        layout->paddingLeft(paddingLeft);
    }
    Layout::Size paddingRight(getSize(padding["right"]));
    if (!paddingRight.isNull()) {
        layout->paddingRight(paddingRight);
    }

    QJsonObject border = config["border"].toObject();
    Layout::Size borderTop(getSize(border["top"]));
    if (!borderTop.isNull()) {
        layout->borderTop(borderTop);
    }
    Layout::Size borderBottom(getSize(border["bottom"]));
    if (!borderBottom.isNull()) {
        layout->borderBottom(borderBottom);
    }
    Layout::Size borderLeft(getSize(border["left"]));
    if (!borderLeft.isNull()) {
        layout->borderLeft(borderLeft);
    }
    Layout::Size borderRight(getSize(border["right"]));
    if (!borderRight.isNull()) {
        layout->borderRight(borderRight);
    }

    if (config["borderOverlap"].isBool()) {
        bool overlap = config["borderOverlap"].toBool();
        layout->borderOverlap(overlap);
    }

    QJsonObject margin = config["margin"].toObject();
    Layout::Size marginTop(getSize(margin["top"]));
    if (!marginTop.isNull()) {
        layout->marginTop(marginTop);
    }
    Layout::Size marginBottom(getSize(margin["bottom"]));
    if (!marginBottom.isNull()) {
        layout->marginBottom(marginBottom);
    }
    Layout::Size marginLeft(getSize(margin["left"]));
    if (!marginLeft.isNull()) {
        layout->marginLeft(marginLeft);
    }
    Layout::Size marginRight(getSize(margin["right"]));
    if (!marginRight.isNull()) {
        layout->marginRight(marginRight);
    }

    if (config["marginOverlap"].isBool()) {
        bool overlap = config["marginOverlap"].toBool();
        layout->marginOverlap(overlap);
    }
}

}
