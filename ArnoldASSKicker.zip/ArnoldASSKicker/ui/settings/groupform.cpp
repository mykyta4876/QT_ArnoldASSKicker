#include "groupform.h"
#include "../layoutload.h"

GroupForm::GroupForm(QWidget* parent, QString name, QString title) :
    _widget(new QGroupBox(parent)),
    _events(nullptr),
    _layout(new Layout(name, _widget))
{
    _widget->setObjectName(name);
    _widget->setTitle(title);
}

GroupForm::~GroupForm()
{
    if (_layout != nullptr) {
        delete _layout;
    }

    for (CommandField* command : _commands) {
        delete command;
    }
}

QWidget* GroupForm::widget()
{
    return _widget;
}

GroupForm::Events* GroupForm::events()
{
    return _events;
}

int GroupForm::numCommands()
{
    return _commands.size();
}

QString GroupForm::commandName(int index)
{
    CommandField* command = this->command(index);
    if (command == nullptr) return QString();

    return command->checkBox()->objectName();
}

CommandField* GroupForm::command(int index)
{
    if (index < 0 || numCommands() <= index) return nullptr;

    return _commands[index];
}

CommandField* GroupForm::command(QString name)
{
    int n = numCommands();
    for (int i = 0; i < n; i++) {
        if (commandName(i) == name) return command(i);
    }
    return nullptr;
}

void GroupForm::addCommand(QString name, QString label, QString statusTip)
{
    CommandField* command = new CommandField(_widget, name, label, statusTip);
    command->setEvents(_events);
    _commands.append(command);
}

void GroupForm::setEvents(Events* events)
{
    _events = events;

    for (CommandField* command : _commands) {
        command->setEvents(_events);
    }
}

void GroupForm::render()
{
    //TODO: figure out why this line is needed???
    _widget->show();

    performLayout();
}

void GroupForm::loadLayout(QJsonObject& config)
{
    QString key = _widget->objectName();
    if (config[key].isObject()) {
        QJsonObject config2 = config[key].toObject();
        LayoutLoad::fromJson(_layout, config2);
    } else {
        LayoutLoad::fromJson(_layout, config);
    }
}

void GroupForm::performLayout()
{
    _layout->width(_widget->width()).height(_widget->height());
    _layout->update();
}

void GroupForm::setupStyleSheet()
{
    _widget->setStyleSheet(
        "#settings {\n"
        "	background: rgb(50, 50, 50);\n"
        "}\n"
        "\n");
}
