#ifndef PARAMETERINPUT_H
#define PARAMETERINPUT_H

#include <QComboBox>
#include <QLineEdit>

class ParameterInput
{
public:
    class Events {
    public:
        virtual ~Events() {}

        virtual void changed(QString name, QString value) = 0;
    };

    ParameterInput(QWidget* parent, QString name, QString type);

    QWidget* widget();
    Events* events();

    void addOption(QString label);
    void setValue(QString value);
    void setEvents(Events* events);
    void render();

private:
    QComboBox* _comboBox;
    QLineEdit* _lineEdit;
    Events* _events;
};

#endif // PARAMETERINPUT_H
