#ifndef GROUPFORM_H
#define GROUPFORM_H

#include "commandfield.h"
#include "../layout.h"

#include <QGroupBox>

class GroupForm
{
public:
    using Events = CommandField::Events;

    GroupForm(QWidget* parent, QString name, QString title);
    ~GroupForm();

    QWidget* widget();
    Events* events();

    int numCommands();
    QString commandName(int index);
    CommandField* command(int index);
    CommandField* command(QString name);

    void addCommand(QString name, QString label, QString statusTip);

    void setEvents(Events* events);
    void render();

    void loadLayout(QJsonObject& config);

    QString layoutDebugString(int indent = 0) {
        return _layout->debugString(indent);
    }

private:
    QGroupBox* _widget;
    Events* _events;
    Layout* _layout;

    QList<CommandField*> _commands;

    void performLayout();
    void setupStyleSheet();
};

#endif // GROUPFORM_H
