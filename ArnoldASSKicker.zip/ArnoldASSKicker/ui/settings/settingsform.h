#ifndef SETTINGSFORM_H
#define SETTINGSFORM_H

#include "groupform.h"

class SettingsForm
{
public:
    using Events = GroupForm::Events;

    SettingsForm(QWidget* parent = nullptr);
    ~SettingsForm();

    QWidget* widget();
    Events* events();

    int numGroups();
    QString groupName(int index);
    GroupForm* group(int index);
    GroupForm* group(QString name);

    void addGroup(QString name, QString title);

    void setEvents(Events* events);
    void render();

    void loadLayout(QJsonObject& config);

    QString layoutDebugString();

private:
    QWidget* _widget;
    Events* _events;
    Layout* _layout;

    QList<GroupForm*> _groups;

    void performLayout();
    void setupStyleSheet();
};

#endif // SETTINGSFORM_H
