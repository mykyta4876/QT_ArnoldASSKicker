#include "parameterinput.h"

ParameterInput::ParameterInput(QWidget* parent, QString name, QString type) :
    _comboBox(nullptr),
    _lineEdit(nullptr)
{
    if (type == "select") {
        _comboBox = new QComboBox(parent);

        QObject::connect(_comboBox, &QComboBox::currentIndexChanged, _comboBox, [=](int index) {
            if (_events != nullptr) {
                QString name = _comboBox->objectName();
                QString value = _comboBox->itemText(index);
                _events->changed(name, value);
            }
        });
    } else {
        _lineEdit = new QLineEdit(parent);

        QObject::connect(_lineEdit, &QLineEdit::textEdited, _lineEdit, [=](const QString& text) {
            if (_events != nullptr) {
                QString name = _lineEdit->objectName();
                _events->changed(name, text);
            }
        });
    }

    widget()->setObjectName(name);
}

QWidget* ParameterInput::widget()
{
    if (_comboBox != nullptr) return _comboBox;

    return _lineEdit;
}

ParameterInput::Events* ParameterInput::events()
{
    return _events;
}

void ParameterInput::addOption(QString label)
{
    if (_comboBox != nullptr) {
        _comboBox->addItem(label);
    }
}

void ParameterInput::setValue(QString value)
{
    if (_comboBox != nullptr) {
        _comboBox->setCurrentText(value);
    } else {
        _lineEdit->setText(value);
    }
}

void ParameterInput::setEvents(Events* events)
{
    _events = events;
}

void ParameterInput::render()
{
    //
}
