#ifndef COMMANDFIELD_H
#define COMMANDFIELD_H

#include "parameterinput.h"

#include <QCheckBox>

class CommandField
{
public:
    class Events : public ParameterInput::Events {
    public:
        virtual ~Events() {}

        virtual void enabled(QString name) = 0;
        virtual void disabled(QString name) = 0;
    };

    CommandField(
        QWidget* parent,
        QString name,
        QString label,
        QString statusTip);
    ~CommandField();

    QCheckBox* checkBox();
    Events* events();

    int numParameters();
    QString parameterName(int index);
    ParameterInput* parameter(int index);
    ParameterInput* parameter(QString name);

    void enable(bool enabled = true);
    void disable();
    void addParameter(QString name, QString type);

    void setEvents(Events* events);
    void render();

private:
    QCheckBox* _checkBox;
    Events* _events;

    QList<ParameterInput*> _parameters;
};

#endif // COMMANDFIELD_H
