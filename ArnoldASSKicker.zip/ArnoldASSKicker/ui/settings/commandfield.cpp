#include "commandfield.h"

CommandField::CommandField(
    QWidget* parent,
    QString name,
    QString label,
    QString statusTip)
    :
    _checkBox(new QCheckBox(parent)),
    _events(nullptr)
{
    _checkBox->setObjectName(name);
    _checkBox->setText(label);
    _checkBox->setStatusTip(statusTip);

    QObject::connect(_checkBox, &QCheckBox::clicked, _checkBox, [=](bool checked) {
        if (_events != nullptr) {
            QString name = _checkBox->objectName();
            if (checked) {
                _events->enabled(name);
            } else {
                _events->disabled(name);
            }
        }
    });
}

CommandField::~CommandField()
{
    for (ParameterInput* parameter : _parameters) {
        delete parameter;
    }
}

QCheckBox* CommandField::checkBox()
{
    return _checkBox;
}

CommandField::Events* CommandField::events()
{
    return _events;
}

int CommandField::numParameters()
{
    return _parameters.size();
}

QString CommandField::parameterName(int index)
{
    ParameterInput* parameter = this->parameter(index);
    if (parameter == nullptr) return QString();

    return parameter->widget()->objectName();
}

ParameterInput* CommandField::parameter(int index)
{
    if (index < 0 || numParameters() <= index) return nullptr;

    return _parameters[index];
}

ParameterInput* CommandField::parameter(QString name)
{
    int n = numParameters();
    for (int i = 0; i < n; i++) {
        if (parameterName(i) == name) return parameter(i);
    }
    return nullptr;
}

void CommandField::enable(bool enabled)
{
    _checkBox->setChecked(enabled);
}

void CommandField::disable()
{
    enable(false);
}

void CommandField::addParameter(QString name, QString type)
{
    QWidget* parent = _checkBox->parentWidget();
    ParameterInput* parameter = new ParameterInput(parent, name, type);
    parameter->setEvents(_events);
    _parameters.append(parameter);
}

void CommandField::setEvents(Events* events)
{
    _events = events;

    for (ParameterInput* parameter : _parameters) {
        parameter->setEvents(_events);
    }
}

void CommandField::render()
{
    for (ParameterInput* parameter : _parameters) {
        parameter->render();
    }
}
