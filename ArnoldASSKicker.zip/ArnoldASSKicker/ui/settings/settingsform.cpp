#include "settingsform.h"
#include "../layoutload.h"

#include <QDebug>

SettingsForm::SettingsForm(QWidget* parent) :
    _widget(new QWidget(parent)),
    _events(nullptr),
    _layout(new Layout("settings", _widget))
{
    _widget->setObjectName("settings");
}

SettingsForm::~SettingsForm()
{
    if (_layout != nullptr) {
        delete _layout;
    }

    for (GroupForm* group : _groups) {
        delete group;
    }
}

QWidget* SettingsForm::widget()
{
    return _widget;
}

SettingsForm::Events* SettingsForm::events()
{
    return _events;
}

int SettingsForm::numGroups()
{
    return _groups.size();
}

QString SettingsForm::groupName(int index)
{
    GroupForm* group = this->group(index);
    if (group == nullptr) return QString();

    return group->widget()->objectName();
}

GroupForm* SettingsForm::group(int index)
{
    if (index < 0 || numGroups() <= index) return nullptr;

    return _groups[index];
}

GroupForm* SettingsForm::group(QString name)
{
    int n = numGroups();
    for (int i = 0; i < n; i++) {
        if (groupName(i) == name) return group(i);
    }
    return nullptr;
}

void SettingsForm::addGroup(QString name, QString title)
{
    GroupForm* group = new GroupForm(_widget, name, title);
    group->setEvents(_events);
    _groups.append(group);
}

void SettingsForm::setEvents(Events* events)
{
    _events = events;

    for (GroupForm* group : _groups) {
        group->setEvents(_events);
    }
}

void SettingsForm::render()
{
    performLayout();

    for (GroupForm* group : _groups) {
        group->render();
    }
}

void SettingsForm::loadLayout(QJsonObject& config)
{
    QString key = _widget->objectName();
    if (config[key].isObject()) {
        QJsonObject config2 = config[key].toObject();
        LayoutLoad::fromJson(_layout, config2);

    } else {
        LayoutLoad::fromJson(_layout, config);
    }

    for (GroupForm* group : _groups) {
        group->loadLayout(config);
    }
}

QString SettingsForm::layoutDebugString()
{
    QString str = _layout->debugString();
    for (GroupForm* group : _groups) {
        str += "\n\n" + group->layoutDebugString();
    }
    return str;
}

void SettingsForm::performLayout()
{
    _layout->width(_widget->width()).height(_widget->height());
    _layout->update();
}

void SettingsForm::setupStyleSheet()
{
    qDebug() << "SettingsForm::setupStyleSheet";

    _widget->setStyleSheet(
        "#settings * {\n"
        "	background: rgb(250, 250, 250);\n"
        "}\n"
        "#settings_animation, #settings_animation > * {\n"
        "	background: rgb(250, 50, 50);\n"
        "	border: 5px solid rgb(250, 0, 0);\n"
        "}\n"
        "#settings_render, #settings_render > * {\n"
        "	background: rgb(50, 250, 50);\n"
        "	border: 5px solid rgb(250, 0, 0);\n"
        "}\n"
        "#settings_raytracing, #settings_raytracing > * {\n"
        "	background: rgb(50, 50, 250);\n"
        "	border: 5px solid rgb(250, 0, 0);\n"
        "}\n"
        "#settings_disable, #settings_disable > * {\n"
        "	background: rgb(250, 250, 50);\n"
        "	border: 5px solid rgb(250, 0, 0);\n"
        "}\n"
        "#settings_misc, #settings_misc > * {\n"
        "	background: rgb(250, 50, 250);\n"
        "	border: 5px solid rgb(250, 0, 0);\n"
        "}\n"
        "#settings_ignore, #settings_ignore > * {\n"
        "	background: rgb(50, 250, 250);\n"
        "	border: 5px solid rgb(250, 0, 0);\n"
        "}\n"
        "\n");
}
