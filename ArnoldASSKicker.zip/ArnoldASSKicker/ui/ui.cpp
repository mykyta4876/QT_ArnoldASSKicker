#include "ui.h"

#include <QMessageBox>
#include <QThread>

UI::UI() :
    _currentPage(Page::Main),
    _window(),
    _mainPage(_window.widget()),
    _windowEvents(*this),
    _mainPageEvents(*this)
{
    _window.setTitle("");
    _window.setEvents(&_windowEvents);
    _window.addPage(_mainPage.widget());
    _window.widget()->showMaximized();
    _window.widget()->setWindowIcon(QIcon(":/icon"));
    //_window.resizeContents(3840, 2160);

    _mainPage.setEvents(&_mainPageEvents);
}

MainWindow& UI::window()
{
    return _window;
}

QWidget* UI::widget()
{
    return _window.widget();
}

UI::Page UI::currentPage()
{
    return _currentPage;
}

MainPage& UI::mainPage()
{
    return _mainPage;
}

PreferencesForm& UI::preferences()
{
    return _mainPage.preferences();
}

FileSequenceView& UI::fileSequence()
{
    return _mainPage.fileSequence();
}

SettingsForm& UI::settings()
{
    return _mainPage.settings();
}

void UI::showError(QString error, QString title)
{
    QMessageBox::critical(_window.widget(), title, error);
}

void UI::changePage(UI::Page page)
{
    if (page == _currentPage) return;

    _currentPage = page;

    switch (page) {
    case Page::Main:
        _window.showPage(_mainPage.widget());
        break;
    }
}

void UI::render()
{
    _window.show();
    _window.render();

    if (_currentPage == Page::Main) {
        _window.hideFrame();
    } else {
        _window.showFrame();
    }

    switch (_currentPage) {
    case Page::Main:
        _mainPage.render();
        break;
    }

    //showSizeDebug("mainWindow");
    //showSizeDebug("mainWindow_viewport");
    //showSizeDebug("centralWidget");
    //showSizeDebug("devConsole");
    //showSizeDebug("devConsole_editor");
    //showSizeDebug("devConsole_save");
    //showSizeDebug("splitter");
    //showSizeDebug("leftPane");
    //showSizeDebug("renderOutput");
    //showSizeDebug("fileSequence");
    //showSizeDebug("footer");
    //showSizeDebug("settings");
    //showSizeDebug("settings_animation");
    //showSizeDebug("settings_disable");
    //showSizeDebug("settings_ignore");
    //showSizeDebug("settings_misc");
    //showSizeDebug("settings_raytracing");
    //showSizeDebug("settings_render");
}

void UI::showSizeDebug(QString widgetName)
{
    if (!_sizeDebugList.contains(widgetName)) {
        _sizeDebugList.append(widgetName);
    }

    QString windowTitle;

    for (QString& name : _sizeDebugList) {
        QWidget* widget = this->widget();
        if (widget->objectName() != name) {
            widget = widget->findChild<QWidget*>(name);
        }
        if (widget == nullptr) continue;

        windowTitle += name + ": " +
           QString::number(widget->width()) + " x " +
           QString::number(widget->height()) + ", ";
    }

    window().setTitle(windowTitle);
}
