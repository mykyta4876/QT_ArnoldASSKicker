#ifndef LAYOUTLOAD_H
#define LAYOUTLOAD_H

#include "layout.h"

#include <QJsonArray>
#include <QJsonObject>

namespace LayoutLoad
{

QJsonObject toJson(Layout* layout);
void toJson(Layout* layout, QJsonObject& config);

Layout* fromJson(QString& json);
Layout* fromJson(QJsonObject& config);

void fromJson(Layout* layout, QString& json);
void fromJson(Layout* layout, QJsonObject& config);

//Detail
QWidget* topLevelWidget(Layout* layout);
void buildTree(QJsonArray& tree, Layout* layout, QWidget* widget = nullptr);
Layout::Size getSize(QJsonValue value);
void configureLayout(Layout* layout, QJsonObject& config);

}

#endif // LAYOUTLOAD_H
