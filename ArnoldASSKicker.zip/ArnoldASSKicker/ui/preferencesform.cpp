#include "preferencesform.h"
#include "layoutload.h"

#include <QFileDialog>

PreferencesForm::PreferencesForm(QWidget* parent) :
    _widget(new QWidget(parent)),
    _model(nullptr),
    _events(nullptr),
    _layout(new Layout("prefs", _widget)),
    _ignoreLicHost(new QCheckBox(_widget)),
    _lastUsedDir(new QCheckBox(_widget)),
    _clearOnRender(new QCheckBox(_widget)),
    _notifyOnSeqCompletion(new QCheckBox(_widget)),
    _arguments(new QLineEdit(_widget)),
    _save(new QPushButton(_widget)),
    _resetUI(new QPushButton(_widget)),
    _saveUI(new QPushButton(_widget)),
    _killRender(new QPushButton(_widget)),
    _render(new QPushButton(_widget))
{
    _kick.label = new QLabel(_widget);
    _kick.path = new QLineEdit(_widget);
    _kick.browse = new QPushButton(_widget);

    _shaders.label = new QLabel(_widget);
    _shaders.path = new QLineEdit(_widget);
    _shaders.browse = new QPushButton(_widget);

    _widget->setObjectName("prefs");
    _kick.label->setObjectName("prefs_kickLabel");
    _kick.path->setObjectName("prefs_kickPath");
    _kick.browse->setObjectName("prefs_kickBrowse");
    _shaders.label->setObjectName("prefs_shadersLabel");
    _shaders.path->setObjectName("prefs_shadersPath");
    _shaders.browse->setObjectName("prefs_shadersBrowse");
    _ignoreLicHost->setObjectName("prefs_ignoreLicHost");
    _lastUsedDir->setObjectName("prefs_lastUsedDir");
    _clearOnRender->setObjectName("prefs_clearOnRender");
    _notifyOnSeqCompletion->setObjectName("prefs_notifyOnSeqCompletion");
    _arguments->setObjectName("prefs_arguments");
    _save->setObjectName("prefs_save");
    _resetUI->setObjectName("prefs_resetUI");
    _saveUI->setObjectName("prefs_saveUI");
    _killRender->setObjectName("prefs_killRender");
    _render->setObjectName("prefs_render");

    _save->setFlat(true);

    _kick.label->setText("Path to kick binary:");
    _kick.path->setPlaceholderText("/Path/To/Kick");
    _kick.browse->setText("Browse");
    _shaders.label->setText("Path to shaders:");
    _shaders.path->setPlaceholderText("/Path/To/Shaders");
    _shaders.browse->setText("Browse");
    _ignoreLicHost->setText("Ignore license host?");
    _lastUsedDir->setText("Remember last used dir?");
    _clearOnRender->setStatusTip("Clears the output window on render.");
    _clearOnRender->setText("Clear on render");
    _notifyOnSeqCompletion->setText("Notify on seq completion");
    _save->setText("Save");
    _resetUI->setStatusTip("Resets the current state of the interface to the default.");
    _resetUI->setText("Reset Settings");
    _saveUI->setStatusTip("Saves the current state of the interface.");
    _saveUI->setText("Save current UI");
    _killRender->setToolTip("Command W");
    _killRender->setStatusTip("Stops an active render.");
    _killRender->setText("Kill Render");
    _killRender->setShortcut(QKeySequence("Ctrl+W"));
    _render->setToolTip("Command R");
    _render->setStatusTip("Render the input files.");
    _render->setText("Render");
    _render->setShortcut(QKeySequence("Ctrl+R"));

    QObject::connect(_kick.browse, &QPushButton::clicked, [=]() {
        kickBrowse();
    });
    QObject::connect(_shaders.browse, &QPushButton::clicked, [=]() {
        shadersBrowse();
    });
    QObject::connect(_render, &QPushButton::clicked, [&]() {
        if (_events != nullptr) {
            _events->render();
        }
    });
    QObject::connect(_killRender, &QPushButton::clicked, [&]() {
        if (_events != nullptr) {
            _events->killRender();
        }
    });

    auto getData = [&]() {
        Events::Data data;
        data.ignoreLicHost = _ignoreLicHost->isChecked();
        data.lastUsedDir = _lastUsedDir->isChecked();
        data.clearOnRender = _clearOnRender->isChecked();
        data.notifyOnSeqCompletion = _notifyOnSeqCompletion->isChecked();
        return data;
    };

    QObject::connect(_ignoreLicHost, &QCheckBox::clicked, [=](bool checked) {
        if (_events == nullptr) return;

        Events::Data data = getData();
        data.ignoreLicHost = checked;

        _events->changed(data);
    });

    QObject::connect(_lastUsedDir, &QCheckBox::clicked, [=](bool checked) {
        if (_events == nullptr) return;

        Events::Data data = getData();
        data.lastUsedDir = checked;

        _events->changed(data);
    });

    QObject::connect(_clearOnRender, &QCheckBox::clicked, [=](bool checked) {
        if (_events == nullptr) return;

        Events::Data data = getData();
        data.clearOnRender = checked;

        _events->changed(data);
    });

    QObject::connect(_notifyOnSeqCompletion, &QCheckBox::clicked, [=](bool checked) {
        if (_events == nullptr) return;

        Events::Data data = getData();
        data.notifyOnSeqCompletion = checked;

        _events->changed(data);
    });
}

PreferencesForm::~PreferencesForm()
{
    if (_layout != nullptr) {
        delete _layout;
    }
}

QWidget* PreferencesForm::widget()
{
    return _widget;
}

PreferencesForm::Model* PreferencesForm::model()
{
    return _model;
}

PreferencesForm::Events* PreferencesForm::events()
{
    return _events;
}

void PreferencesForm::setModel(Model* model)
{
    _model = model;
}

void PreferencesForm::setEvents(Events* events)
{
    _events = events;
}

void PreferencesForm::render()
{
    performLayout();
    setupStyleSheet();

    if (_model == nullptr) return;

    Data data  = _model->data();
    _ignoreLicHost->setChecked(data.ignoreLicHost);
    _lastUsedDir->setChecked(data.lastUsedDir);
    _clearOnRender->setChecked(data.clearOnRender);
    _notifyOnSeqCompletion->setChecked(data.notifyOnSeqCompletion);
    _arguments->setText(_model->arguments());
    _kick.path->setText(_model->kickPath());
    _shaders.path->setText(_model->shadersPath());
}

void PreferencesForm::loadLayout(QJsonObject& config)
{
    QString key = _widget->objectName();
    if (config[key].isObject()) {
        QJsonObject config2 = config[key].toObject();
        LayoutLoad::fromJson(_layout, config2);
    } else {
        LayoutLoad::fromJson(_layout, config);
    }
}

void PreferencesForm::kickBrowse()
{
    QString path = QFileDialog::getOpenFileName(
        _widget->topLevelWidget(),
        "Select the kick binary", "", "Files (*)");

    if (_events != nullptr) {
        _events->kickPathSelected(path);
    }
}

void PreferencesForm::shadersBrowse()
{
    QString path = QFileDialog::getExistingDirectory(
        _widget->topLevelWidget(),
        "Select the folder containing any shaders "
        "(.dylib, .so, .dll files)", "",
        QFileDialog::ShowDirsOnly);

    if (_events != nullptr) {
        _events->shadersPathSelected(path);
    }
}

void PreferencesForm::performLayout()
{
    _layout->width(_widget->width()).height(_widget->height());
    _layout->update();
}

void PreferencesForm::setupStyleSheet()
{
    _widget->setStyleSheet(
        "#prefs_killRender {\n"
        "	color: rgb(240, 70, 45);\n"
        "	font-weight: bold;\n"
        "}\n"
        "\n"
        "#prefs_render {\n"
        "	color: rgb(45, 200, 45);\n"
        "	font-weight: bold;\n"
        "}\n"
        "\n");
}
