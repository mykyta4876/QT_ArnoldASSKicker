#ifndef LAYOUT_H
#define LAYOUT_H

#include <QList>
#include <QWidget>

class Layout
{
public:
    enum Alignment {
        Top,
        Left,
        Center,
        Right,
        Bottom
    };

    enum Orientation {
        Horizontal,
        Vertical
    };

    enum Unit {
        Pixels,
        Percent,
        Aspect,
        None
    };

    class Size {
    public:
        int value;
        Unit unit;

        Size() :
            value(0),
            unit(None),
            _computed(0)
        {}

        Size(int value, Unit unit = Pixels) :
            value(value),
            unit(unit),
            _computed(0)
        {}

        bool isNull() { return unit == None; }
        int computed() { return _computed; }
        operator int() { return _computed; }

    private:
        friend Layout;
        int _computed;

        Size& operator =(int x) { _computed = x; return *this; }
        Size& operator =(Size& size) {
            value = size.value;
            unit = size.unit;
            return *this;
        }
    };

    template <typename T>
    struct Quad {
        T top;
        T bottom;
        T left;
        T right;

        Quad() {}

        Quad(T value) :
            top(value),
            bottom(value),
            left(value),
            right(value)
        {}

        Quad(T topBottom, T rightLeft) :
            top(topBottom),
            bottom(topBottom),
            left(rightLeft),
            right(rightLeft)
        {}

        Quad(T top, T right, T bottom, T left) :
            top(top),
            bottom(bottom),
            left(left),
            right(right)
        {}
    };

    using SizeQuad = Quad<Size>;

    Layout(QWidget* widget = nullptr);
    Layout(QString name, QWidget* widget = nullptr);
    ~Layout();

    QString name();
    QWidget* widget();

    Alignment alignment();
    Orientation orientation();
    int flex();

    int offsetX();
    int offsetY();

    Size width();
    Size height();

    Size contentWidth();
    Size contentHeight();

    SizeQuad padding();
    Size paddingTop();
    Size paddingBottom();
    Size paddingLeft();
    Size paddingRight();

    SizeQuad border();
    Size borderTop();
    Size borderBottom();
    Size borderLeft();
    Size borderRight();

    bool borderOverlap();

    SizeQuad margin();
    Size marginTop();
    Size marginBottom();
    Size marginLeft();
    Size marginRight();

    bool marginOverlap();

    Layout* root();
    Layout* parent();
    Layout* child(int index);
    int numChildren();

    //bool isParentOf(Layout* layout);
    //bool isAncestorOf(Layout* layout);
    //bool isChildOf(Layout* layout);
    //bool isDescendantOf(Layout* layout);
    //bool isSiblingOf(Layout* layout);

    Layout* find(QString name, bool recurse = true);
    Layout* findChild(QString name);
    QList<Layout*> findAll(QString name, bool recurse = true);
    QList<Layout*> findChildren(QString name);

    Layout& name(QString name);
    Layout& widget(QWidget* widget);

    Layout& alignment(Alignment alignment);
    Layout& orientation(Orientation orientation);
    Layout& flex(int flex);

    Layout& offset(int x, int y);
    Layout& offsetX(int x);
    Layout& offsetY(int y);

    Layout& resize(Size width, Size height);
    Layout& width(Size width);
    Layout& height(Size height);

    Layout& content(Size width, Size height);
    Layout& contentWidth(Size width);
    Layout& contentHeight(Size height);

    Layout& padding(SizeQuad width);
    Layout& padding(Size topBottom, Size rightLeft);
    Layout& padding(Size top, Size right, Size bottom, Size left);
    Layout& paddingTop(Size width);
    Layout& paddingBottom(Size width);
    Layout& paddingLeft(Size width);
    Layout& paddingRight(Size width);

    Layout& border(SizeQuad width);
    Layout& border(Size topBottom, Size rightLeft);
    Layout& border(Size top, Size right, Size bottom, Size left);
    Layout& borderTop(Size width);
    Layout& borderBottom(Size width);
    Layout& borderLeft(Size width);
    Layout& borderRight(Size width);

    Layout& borderOverlap(bool flag);

    Layout& margin(SizeQuad width);
    Layout& margin(Size topBottom, Size rightLeft);
    Layout& margin(Size top, Size right, Size bottom, Size left);
    Layout& marginTop(Size width);
    Layout& marginBottom(Size width);
    Layout& marginLeft(Size width);
    Layout& marginRight(Size width);

    Layout& marginOverlap(bool flag);

    Layout& parent(Layout* layout);
    Layout& child(Layout* layout);
    Layout& child(Layout& layout);
    Layout& child(int index, Layout* layout);
    Layout& children(QList<Layout*>& layouts);
    Layout& children(int index, QList<Layout*>& layouts);

    Layout& removeParent(bool delete_ = false);
    Layout& removeChild(int index, bool delete_ = false);
    Layout& clearChildren(bool delete_ = false);

    void update();

    QString debugString(int indent = 0);

private:
    QString _name;
    QWidget* _widget;
    Alignment _alignment;
    Orientation _orientation;
    int _flex;
    int _offsetX;
    int _offsetY;
    Size _width;
    Size _height;
    Size _contentWidth;
    Size _contentHeight;
    SizeQuad _padding;
    SizeQuad _border;
    SizeQuad _margin;
    bool _borderOverlap;
    bool _marginOverlap;
    Layout* _parent;
    QList<Layout*> _children;

    void computeRoot();
    QRect computeGeometry();
    void computeSize(Size& size, int widthOrHeight);
    void computeSizeQuad(SizeQuad& size, int width, int height);
    void computeBox(Layout& child);
    void alignChild(Layout& child);
    void alignTop(Layout& child);
    void alignBottom(Layout& child);
    void alignLeft(Layout& child);
    void alignRight(Layout& child);
    void alignChild(Layout& child, Layout& previousChild);
    void alignTop(Layout& child, Layout& previousChild);
    void alignLeft(Layout& child, Layout& previousChild);
    void computeFlex();

    QString debugString(Size& size, QString name, QString indentStr);
    QString debugString(SizeQuad& size, QString name, QString indentStr);
};

int operator +(Layout::Size& size, int x);
int operator +(int x, Layout::Size& size);
int operator +(Layout::Size& size1, Layout::Size& size2);

int operator *(Layout::Size& size, int x);
int operator *(int x, Layout::Size& size);
int operator *(Layout::Size& size1, Layout::Size& size2);

int operator -(Layout::Size& size, int x);
int operator -(int x, Layout::Size& size);
int operator -(Layout::Size& size1, Layout::Size& size2);

int operator /(Layout::Size& size, int x);
int operator /(int x, Layout::Size& size);
int operator /(Layout::Size& size1, Layout::Size& size2);

#endif // LAYOUT_H
