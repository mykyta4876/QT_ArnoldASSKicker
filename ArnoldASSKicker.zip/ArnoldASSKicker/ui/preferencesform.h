#ifndef PREFERENCESFORM_H
#define PREFERENCESFORM_H

#include "layout.h"

#include <QCheckBox>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>

class PreferencesForm
{
public:
    struct Data {
        bool ignoreLicHost;
        bool lastUsedDir;
        bool clearOnRender;
        bool notifyOnSeqCompletion;
    };

    class Model {
    public:
        using Data = PreferencesForm::Data;

        virtual ~Model() {}

        virtual Data data() = 0;
        virtual QString arguments() = 0;
        virtual QString kickPath() = 0;
        virtual QString shadersPath() = 0;
    };

    class Events {
    public:
        using Data = PreferencesForm::Data;

        virtual ~Events() {}

        virtual void changed(Data data) = 0;
        virtual void kickPathSelected(QString path) = 0;
        virtual void shadersPathSelected(QString path) = 0;

        virtual void render() = 0;
        virtual void killRender() = 0;
    };

    PreferencesForm(QWidget* parent = nullptr);
    ~PreferencesForm();

    QWidget* widget();
    Model* model();
    Events* events();

    void setModel(Model* model);
    void setEvents(Events* events);
    void render();

    void loadLayout(QJsonObject& config);

    QString layoutDebugString() { return _layout->debugString(); }

private:
    QWidget* _widget;
    Model* _model;
    Events* _events;
    Layout* _layout;

    struct {
        QLabel* label;
        QLineEdit* path;
        QPushButton* browse;
    }
    _kick,
    _shaders;

    QCheckBox* _ignoreLicHost;
    QCheckBox* _lastUsedDir;
    QCheckBox* _clearOnRender;
    QCheckBox* _notifyOnSeqCompletion;

    QLineEdit* _arguments;

    QPushButton* _save;
    QPushButton* _resetUI;
    QPushButton* _saveUI;
    QPushButton* _killRender;
    QPushButton* _render;

    void kickBrowse();
    void shadersBrowse();

    void performLayout();
    void setupStyleSheet();
};

#endif // PREFERENCESFORM_H
