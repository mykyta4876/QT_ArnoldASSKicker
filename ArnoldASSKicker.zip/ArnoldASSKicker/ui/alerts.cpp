#include "alerts.h"

#include <QMessageBox>

//TODO: move text content into config file

void Alerts::exec(QString msg, QString info)
{
    QMessageBox alert;
    alert.setText(msg);
    alert.setInformativeText(info);
    alert.setStandardButtons(QMessageBox::Ok);
    alert.setDefaultButton(QMessageBox::Ok);
    alert.setMinimumSize(500, 200);
    alert.exec();
}

void Alerts::renderFinished(QString msg)
{
    if (msg.isEmpty()) {
        msg = "Rendering finished";
    }

    QString info = "Thank you for waiting. ASS was kicked.";

    exec(msg, info);
}

void Alerts::renderStopped(QString msg)
{
    if (msg.isEmpty()) {
        msg = "Woah nellie, pump the brakes!";
    }

    QString info = "Rendering has been stopped.";

    exec(msg, info);
}

void Alerts::launchKickFailed(QString msg)
{
    if (msg.isEmpty()) {
        msg = "Something happened while trying to launch kick.";
    }

    QString info = "Please check your settings and try again.";

    exec(msg, info);
}

void Alerts::noKickPath(QString msg)
{
    if (msg.isEmpty()) {
        msg = "The path to Kick is not set yet.";
    }

    QString info = "Please set the path to the kick binary in the preferences.";

    exec(msg, info);
}

void Alerts::noFilesSelected(QString msg)
{
    if (msg.isEmpty()) {
        msg = "Umm... doiiii, you prooobably want to select some files to render.";
    }

    QString info = "Please select some .ass files and try again.";

    exec(msg, info);
}
