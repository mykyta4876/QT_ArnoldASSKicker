#ifndef UI_H
#define UI_H

#include "mainpage.h"
#include "mainwindow.h"

class UI
{
public:
    UI();

    enum Page {
        Main
    };

    MainWindow& window();
    QWidget* widget();

    Page currentPage();
    MainPage& mainPage();
    PreferencesForm& preferences();
    FileSequenceView& fileSequence();
    SettingsForm& settings();

    void showError(QString error, QString title = "Error");
    void changePage(Page page);
    void render();

private:
    Page _currentPage;
    MainWindow _window;
    MainPage _mainPage;

    struct WindowEvents : public MainWindow::Events {
        UI& _ui;
        WindowEvents(UI& ui) : _ui(ui) {}
        void resize(int, int) { _ui.render(); }
    };

    struct MainPageEvents : public MainPage::Events {
        UI& _ui;
        MainPageEvents(UI& ui) : _ui(ui) {}
        void splitterMoved(int) { _ui.render(); }
    };

    WindowEvents _windowEvents;
    MainPageEvents _mainPageEvents;

    QList<QString> _sizeDebugList;

    void showSizeDebug(QString widgetName);
};

#endif // UI_H
