#include "app.h"

int main(int argc, char *argv[])
{
    App app(argc, argv);
    return app.run();
}
