#ifndef KICKASSAPP_H
#define KICKASSAPP_H

#include "filesequence/filesequence.h"
#include "settings/settings.h"
#include "ui/ui.h"

#include <QApplication>
#include <QCoreApplication>
#include <QDebug>
#include <QDir>
#include <QFile>
#include <QFileDialog>
#include <QFileSystemModel>
#include <QMessageBox>
#include <QProcess>
#include <QSettings>
#include <QTextStream>

class KickAssApp : public QObject
{
    Q_OBJECT

public:
    KickAssApp(
        UI& ui,
        Settings& settings,
        FileSequence& fileSequence);

    void updateUI();

private:
    using Data = PreferencesForm::Events::Data;

    UI& _ui;
    Settings& _settings;
    FileSequence& _fileSequence;

    QProcess *kickProcess;
    QStringList arguments;
    QString _output;

    //processFinished
    //  determine if kick should be launched again
    //
    //browseFiles
    //clearFiles
    //removeFile
    //
    //buildArguments
    //  -i <input file> ...
    //
    //AssSequenceManager *assManager;
    //
    //  QMap<QString, QStringList> assSequence;
    //  int seqLength;
    //    init to 1
    //    set to 0 when files are cleared
    //    set to length of input file list
    //    set to 1 if input files are not a sequence
    //    relaunch kick if current frame < length

    int currentFrame;

    struct FileSequenceEvents : public FileSequenceView::Events {
        KickAssApp& _ref;
        FileSequenceEvents(KickAssApp& ref) : _ref(ref) {}
        void browse() { _ref.browseFiles(); }
        void clear() { _ref.clearFiles(); }
        void remove(int index, QString path) { _ref.removeFile(index, path); }
        void finishedRemoving() { _ref.updateUI(); }
    } _fileSequenceEvents;

    struct PreferencesFormModel : public PreferencesForm::Model {
        KickAssApp& _ref;
        PreferencesFormModel(KickAssApp& ref) : _ref(ref) {}
        Data data() {
            return Data{
                _ref._settings.ignoreLicHost(),
                _ref._settings.useLastUsedDir(),
                _ref._settings.clearOnRender(),
                _ref._settings.notifyOnSeqCompletion()
            };
        }
        QString arguments() {
            //int index = _ref.arguments.lastIndexOf("-i");
            //QString s = _ref.arguments.sliced(index + 1).join(' ');
            //return s;
            return _ref._settings.toArgString().split(' ').sliced(2).join(' ');
        }
        QString kickPath() { return _ref._settings.kickPath(); }
        //TODO: naming convention mismatch
        QString shadersPath() { return _ref._settings.shaderPath(); }
    } _prefsModel;

    struct PreferencesFormEvents : public PreferencesForm::Events {
        KickAssApp& _ref;
        PreferencesFormEvents(KickAssApp& ref) : _ref(ref) {}
        void changed(Data data) { _ref.prefsChanged(data); }
        void kickPathSelected(QString path) { _ref.kickPathSelected(path); }
        void shadersPathSelected(QString path) { _ref.shadersPathSelected(path); }
        void render() { _ref.render(); }
        void killRender() { _ref.killRender(); }
    } _prefsEvents;

    struct SettingsFormEvents : public SettingsForm::Events {
        KickAssApp& _ref;
        SettingsFormEvents(KickAssApp& ref) : _ref(ref) {}
        void changed(QString, QString) { _ref.updateSettings(); }
        void enabled(QString) { _ref.updateSettings(); }
        void disabled(QString) { _ref.updateSettings(); }
    } _settingsFormEvents;

private slots:
    void updateSettings();

    void prefsChanged(Data data);
    void kickPathSelected(QString path);
    void shadersPathSelected(QString path);
    void processFinished(int exitCode, QProcess::ExitStatus exitStatus);
    bool launchKick();
    void printProcessOutput();
    void browseFiles();
    void clearFiles();
    void removeFile(int index, QString path); //TODO: naming convention
    void killRender(); //NOTE: this is crashing
    void render();
    void resetSettings();
    void buildArguments();
};

#endif // KICKASSAPP_H
