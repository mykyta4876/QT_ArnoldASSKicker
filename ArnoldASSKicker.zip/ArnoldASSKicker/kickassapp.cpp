#include "kickassapp.h"
#include "ui/alerts.h"

#include <QRegularExpression>
#include <QRegularExpressionMatch>
#include <QtGlobal>
#include <QFileInfo>

KickAssApp::KickAssApp(
    UI& ui,
    Settings& settings,
    FileSequence& fileSequence)
    :
    _ui(ui),
    _settings(settings),
    _fileSequence(fileSequence),
    kickProcess(new QProcess(this)),
    _fileSequenceEvents(*this),
    _prefsModel(*this),
    _prefsEvents(*this),
    _settingsFormEvents(*this)
{
    QApplication::setStyle("Plastique");

    connect(kickProcess, SIGNAL(readyReadStandardOutput()), this, SLOT(printProcessOutput()));
    connect(kickProcess, SIGNAL(finished(int , QProcess::ExitStatus )), this, SLOT(processFinished(int , QProcess::ExitStatus )));

    _ui.fileSequence().setEvents(&_fileSequenceEvents);
    _ui.preferences().setModel(&_prefsModel);
    _ui.preferences().setEvents(&_prefsEvents);
    _ui.settings().setEvents(&_settingsFormEvents);

    updateUI();
}

void KickAssApp::updateUI()
{
    buildArguments();
    _ui.preferences().render();

    _ui.fileSequence().setLength(
        _fileSequence.numFrames());

    _ui.fileSequence().clear();
    int n = _fileSequence.numInputs();
    for (int i = 0; i < n; i++) {
        QString path = _fileSequence.input(i)->displayName();
        _ui.fileSequence().add(path);
    }

    _settings.read();
    _settings.writeToUI(_ui.widget());
}

void KickAssApp::updateSettings()
{
    _settings.readFromUI(_ui.widget());
    _settings.write();

    updateUI();
}

void KickAssApp::prefsChanged(Data data)
{
    _settings.ignoreLicHost(data.ignoreLicHost);
    _settings.useLastUsedDir(data.lastUsedDir);
    _settings.clearOnRender(data.clearOnRender);
    _settings.notifyOnSeqCompletion(data.notifyOnSeqCompletion);
    _settings.write();

    updateUI();
}

void KickAssApp::kickPathSelected(QString path)
{
    QFile file(path);
    QString shaderPath = file.fileName();
    QRegularExpression exeRegex("[kK]ick.?e?x?e?");
    shaderPath.remove(exeRegex);

    qDebug() << "##############: " << shaderPath;

    _settings.setKickPath(path);
    _settings.setShaderPath(shaderPath);
    _settings.write();

    updateUI();
}

void KickAssApp::shadersPathSelected(QString path)
{
    _settings.setShaderPath(path);
    _settings.write();

    updateUI();
}

void KickAssApp::processFinished(int exitCode, QProcess::ExitStatus exitStatus)
{
    qDebug() << "processFinished";
    qDebug() << exitCode;
    qDebug() << exitStatus;

    if (exitCode != 0) return;

    if (exitStatus == 1) {
        Alerts::renderStopped();
    }
    if (exitStatus != 0) return;

    qDebug() << "Exited the process successfully.";

    if (!_fileSequence.isSequence()) return;

    if (currentFrame <= _fileSequence.endFrame()) {
        this->buildArguments();
        qDebug() << "-------------------------- RENDERING!!!!!!";
        this->launchKick();

    } else {
        qDebug() << "RENDERING HAS FINISHED!";

        if (_settings.notifyOnSeqCompletion()) {
            Alerts::renderFinished(_settings.titleLabel());
        }
    }
}

bool KickAssApp::launchKick()
{
    QString args = "";
    for (int i = 1; i < arguments.count(); i++)
    {
        args.append(arguments[i]);
        args.append(" ");
    }

    qDebug() << "///////////////////// args ////////////////////////";
    qDebug() << args;
    qDebug() << "/////////////////// end args //////////////////////";

    // Get path to kick.
    QString program = _settings.kickPath();

    qDebug() << "kickPath: " << program;

    // Start this sucker.
    kickProcess->start(program, arguments);

    currentFrame = currentFrame + 1;
    qDebug() << "currentFrame: " << currentFrame;

    return true;
}

void KickAssApp::printProcessOutput()
{
    QString nextOutput = kickProcess->readAllStandardOutput();
    _output += nextOutput;

    _ui.mainPage().appendOutput(nextOutput);
}

void KickAssApp::browseFiles()
{
    qDebug() << "browseFiles";

    // Get folder from last used ass files and set new launch default folder.
    QString dir = "";
    if (_settings.useLastUsedDir()) {
        dir = _settings.lastUsedDir();
        qDebug() << "Last used dir: " << dir;
    } else {
        dir = "";
    }

    QFileDialog dialog(
        _ui.widget(),
        "Select .ass files to render", dir, "Files (*.ass)");

    QStringList fileNames = dialog.getOpenFileNames();
    _fileSequence.add(fileNames);

    qDebug() << "}}} " << _fileSequence.numInputs();

    // Get path for user friendliness.
    // This is the path that the file open dialog opens to next time it's launched.
    QFileInfo path(fileNames[0]);

    _settings.setLastUsedDir(path.absoluteDir().absolutePath());
    _settings.write();

    updateUI();
}

void KickAssApp::clearFiles()
{
    _fileSequence.clear();
    updateUI();
}

void KickAssApp::removeFile(int, QString name)
{
    _fileSequence.removeSequenceName(name);
}

void KickAssApp::killRender()
{
    kickProcess->kill();
}

//Check that some .ass files are selected
//Check that kick path is set
//Build arguments
//Launch kick

void KickAssApp::render()
{
    qDebug() << "render";

    currentFrame = _fileSequence.startFrame();

    if (_settings.clearOnRender()) {
        _output.clear();
    }

    if (_fileSequence.numInputs() == 0) {
        Alerts::noFilesSelected();
        return;
    }

    if (_settings.kickPath().isEmpty()) {
        qDebug() << "Kick path is NOT set.";
        Alerts::noKickPath();
        return;
    }

    qDebug() << "Kick path is set... carry on.";

    this->buildArguments();

    qDebug() << "-------------------------- RENDERING!!!!!!";

    if (!this->launchKick()) {
        qDebug() << "launchProcess() failed!!";
        Alerts::launchKickFailed();
    }
}

void KickAssApp::resetSettings()
{
    qDebug() << "resetSettings";

    _settings.reset();
    updateUI();
}

void KickAssApp::buildArguments()
{
    qDebug() << "buildArguments";

    arguments.clear();
    arguments.append("-nstdin");

    if (_fileSequence.isSequence()) {
        qDebug() << "This is a sequence of .ass files.";

        if (currentFrame <= _fileSequence.endFrame()) {
            QStringList fileNames = _fileSequence.frameFiles(currentFrame);
            for (const QString& fileName : fileNames) {
                arguments.append("-i");
                arguments.append(fileName);
            }
        }
    } else {
        int n = _fileSequence.numFiles();
        for (int i = 0; i < n; i++) {
            arguments.append("-i");
            arguments.append(_fileSequence.fileName(i));
        }
    }

    qDebug() << "arguments: " << arguments;

    arguments.append(_settings.toArgString().split(' '));

    qDebug() << "++++++++++ arguments: " << arguments;
}
