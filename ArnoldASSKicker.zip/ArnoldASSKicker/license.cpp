#include "license.h"

#include <QByteArray>
#include <QCryptographicHash>
#include <QNetworkInterface>
#include <QRegularExpression>
#include <QString>

static const char* LICENSE_DATA =
    "ArnoldASSKicker_MACMACMACMACMACMACMACMACMACMACMACMACMACMACMACMAC";
static const char* DEFAULT_HASH =
    "6ea804e4b439b8f1de082689c3ca45146d90f4191c22434945a619cef1c5dab9";

License::License() {}

bool License::verify()
{
    if (hash(LICENSE_DATA) == DEFAULT_HASH) return true;

    return checkMACAddress();
}

bool License::checkMACAddress()
{
    QStringList addressList = getMACAddressList();
    if (addressList.isEmpty()) return false;

    for (const QString& mac : addressList) {
        if (hash(mac) == LICENSE_DATA) return true;
    }
    return false;
}

QStringList License::getMACAddressList()
{
    QStringList addressList;
    QList<QNetworkInterface> interfaces = QNetworkInterface::allInterfaces();
    for (const QNetworkInterface& interface : interfaces) {
        bool up = interface.flags().testFlag(QNetworkInterface::IsUp);
        bool running = interface.flags().testFlag(QNetworkInterface::IsRunning);
        if (!(up && running)) continue;

        QString macAddress = formatMacAddress(interface.hardwareAddress());
        if (macAddress.isEmpty()) continue;
        if (macAddress == "00:00:00:00:00:00") continue;

        addressList.append(macAddress.toUpper());
    }
    return addressList;
}

QString License::hash(const QString& data)
{
    using Hash = QCryptographicHash;
    Hash::Algorithm sha = Hash::Sha256;
    QByteArray hash = Hash::hash(data.toUtf8(), sha);
    return hash.toHex();
}

QString License::formatMacAddress(QString macAddress)
{
    //parse and normalize mac address
    //read 12 digits, skip separators
    //read 12 digits one pair at a time into a QStringList containing the 6 pairs of digits
    //join the QStringList with a colon

    static QRegularExpression hexRe("[^0-9A-Fa-f]");
    macAddress.remove(hexRe);

    if (macAddress.length() != 12) {
        qWarning() << "Error: MAC address must contain 12 hex digits";
        return QString();
    }

    QStringList bytes;
    for (int i = 0; i < macAddress.length(); i += 2) {
        bytes.append(macAddress.mid(i, 2));
    }
    return bytes.join(':');
}
