#include "mainwindowlayout.h"

MainWindowLayout::MainWindowLayout()
{
    Limits limits = this->limits();

    _screen = limits.screenDefault;
    _window = limits.windowDefault;
    _contents.moveTo(0, 0);
    _contents.setSize(_window);
    _scrollX.geometry.setHeight(limits.scrollBarWidthDefault);
    _scrollY.geometry.setWidth(limits.scrollBarWidthDefault);
    _scrollX.value = 0;
    _scrollY.value = 0;
    _scrollX.scrollUnitsPerPixel = limits.scrollUnitsPerPixelDefault;
    _scrollY.scrollUnitsPerPixel = limits.scrollUnitsPerPixelDefault;
    _resizeTarget = Region::None;
    _contentSizeFixed = false;

    compute();
}

MainWindowLayout::MainWindowLayout(int screenWidth, int screenHeight) :
    MainWindowLayout()
{
    setScreenSize(screenWidth, screenHeight);
}

QSize MainWindowLayout::screen()
{
    return _screen;
}

QSize MainWindowLayout::window()
{
    return _window;
}

QRect MainWindowLayout::viewport()
{
    return _viewport;
}

QRect MainWindowLayout::contents()
{
    return _contents;
}

MainWindowLayout::ScrollBar MainWindowLayout::scrollX()
{
    return _scrollX;
}

MainWindowLayout::ScrollBar MainWindowLayout::scrollY()
{
    return _scrollY;
}

MainWindowLayout::Limits MainWindowLayout::limits()
{
    QSize screenMin(240, 135);
    QSize screenDefault(1920, 1080);

    QSize windowMin(
        2 * _scrollY.geometry.width(),
        2 * _scrollX.geometry.height());

    QSize windowMax(_screen);
    if (_contentSizeFixed) {
        windowMax = QSize(
            qMin(_screen.width(), _contents.width() + _scrollY.geometry.width()),
            qMin(_screen.height(), _contents.height() + _scrollX.geometry.height()));
    }

    QSize windowDefault(
        screenDefault.width() / 2,
        screenDefault.height() / 2);

    int scrollBarWidthMin = 5;
    int scrollBarWidthMax = _screen.width() / 10;
    int scrollBarWidthDefault = 24;
    int scrollUnitsPerPixelDefault = 5;

    return Limits{
        screenMin,
        screenDefault,
        windowMin,
        windowMax,
        windowDefault,
        scrollBarWidthMin,
        scrollBarWidthMax,
        scrollBarWidthDefault,
        scrollUnitsPerPixelDefault
    };
}

void MainWindowLayout::setScreenSize(int width, int height)
{
    Limits limits = this->limits();

    if (width < limits.screenMin.width()) {
        width = limits.screenMin.width();
    }
    if (height < limits.screenMin.height()) {
        height = limits.screenMin.height();
    }

    _screen.setWidth(width);
    _screen.setHeight(height);
}

void MainWindowLayout::autoSize()
{
    QSize window = this->limits().windowMax;
    resize(window.width(), window.height());
}

bool MainWindowLayout::resize(int width, int height)
{
    if (width == _window.width() && height == _window.height()) return false;

    if (_resizeTarget == Region::None) {
        _resizeTarget = Region::Window;
    }

    Limits limits = this->limits();

    if (width < limits.windowMin.width()) {
        width = limits.windowMin.width();
    }
    if (width > limits.windowMax.width()) {
        width = limits.windowMax.width();
    }
    if (height < limits.windowMin.height()) {
        height = limits.windowMin.height();
    }
    if (height > limits.windowMax.height()) {
        height = limits.windowMax.height();
    }

    _window.setWidth(width);
    _window.setHeight(height);

    return compute();
}

bool MainWindowLayout::resizeViewport(int width, int height)
{
    if (_resizeTarget == Region::None) {
        _resizeTarget = Region::Viewport;
    }

    if (_scrollY.visible) {
        width += _scrollY.geometry.width();
    }
    if (_scrollX.visible) {
        height += _scrollX.geometry.height();
    }

    bool resized = resize(width, height);
    _resizeTarget = Region::None;
    return resized;
}

bool MainWindowLayout::resizeContents(int width, int height)
{
    if (width == _contents.width() && height == _contents.height()) return false;

    if (_resizeTarget == Region::None) {
        _resizeTarget = Region::Contents;
    }

    Limits limits = this->limits();

    if (width < limits.windowMin.width()) {
        width = limits.windowMin.width();
    }
    if (height < limits.windowMin.height()) {
        height = limits.windowMin.height();
    }

    _contents.setWidth(width);
    _contents.setHeight(height);

    return compute();
}

void MainWindowLayout::fixContentSize(bool fixed)
{
    _contentSizeFixed = fixed;
}

void MainWindowLayout::setScrollBarWidth(int width)
{
    Limits limits = this->limits();

    if (width < limits.scrollBarWidthMin) {
        width = limits.scrollBarWidthMin;
    }
    if (width > limits.scrollBarWidthMax) {
        width = limits.scrollBarWidthMax;
    }

    _scrollX.geometry.setHeight(width);
    _scrollY.geometry.setWidth(width);

    compute();
}

void MainWindowLayout::setScrollUnitsPerPixel(int scrollUnits)
{
    setScrollUnitsPerPixel(scrollUnits, scrollUnits);
}

void MainWindowLayout::setScrollUnitsPerPixel(int scrollUnitsX, int scrollUnitsY)
{
    if (scrollUnitsX > 0) _scrollX.scrollUnitsPerPixel = scrollUnitsX;
    if (scrollUnitsY > 0) _scrollY.scrollUnitsPerPixel = scrollUnitsY;
}

void MainWindowLayout::scroll(int scrollUnitsX, int scrollUnitsY)
{
    if (scrollUnitsX == 0 && scrollUnitsY == 0) return;

    int numPixelsX = scrollUnitsX / _scrollX.scrollUnitsPerPixel;
    int numPixelsY = scrollUnitsY / _scrollY.scrollUnitsPerPixel;

    if (numPixelsX == 0 && numPixelsY == 0) {
        if (qAbs(scrollUnitsX) > qAbs(scrollUnitsY)) {
            numPixelsX = (scrollUnitsX > 0) ? 1 : -1;
        } else {
            numPixelsY = (scrollUnitsY > 0) ? 1 : -1;
        }
    }

    _scrollX.value -= numPixelsX;
    _scrollY.value -= numPixelsY;

    compute();
}

void MainWindowLayout::scrollX(int scrollUnits)
{
    scroll(scrollUnits, 0);
}

void MainWindowLayout::scrollY(int scrollUnits)
{
    scroll(0, scrollUnits);
}

void MainWindowLayout::scrollTo(int scrollValueX, int scrollValueY)
{
    if (scrollValueX < _scrollX.minimum) {
        scrollValueX = _scrollX.minimum;
    }
    if (scrollValueX > _scrollX.maximum) {
        scrollValueX = _scrollX.maximum;
    }
    if (scrollValueY < _scrollY.minimum) {
        scrollValueY = _scrollY.minimum;
    }
    if (scrollValueY > _scrollY.maximum) {
        scrollValueY = _scrollY.maximum;
    }

    _scrollX.value = scrollValueX;
    _scrollY.value = scrollValueY;

    compute();
}

void MainWindowLayout::scrollXTo(int scrollValue)
{
    scrollTo(scrollValue, _scrollY.value);
}

void MainWindowLayout::scrollYTo(int scrollValue)
{
    scrollTo(_scrollX.value, scrollValue);
}

bool MainWindowLayout::compute()
{
    /*
    If resize target is window
        clamp viewport to window
        clamp contents to viewport if not fixed
        if scrollbar visibility changes, resize viewport
    If resize target is viewport
        clamp window to viewport
        clamp contents to viewport if not fixed
        if scrollbar visibility changes, resize window
    If resize target is contents
        clamp window and viewport to contents
    */

    if (_contentSizeFixed ||
        _resizeTarget == Region::Contents)
    {
        clampToContents();

    } else if (_resizeTarget == Region::Viewport) {
        clampToViewport();

    } else {
        clampToWindow();
    }

    _scrollX.minimum = 0;
    _scrollX.maximum = _contents.width() - _viewport.width();
    _scrollX.pageStep = _viewport.width();
    _scrollX.geometry.moveTo(0, _viewport.height());
    _scrollX.geometry.setWidth(_viewport.width());

    _scrollY.minimum = 0;
    _scrollY.maximum = _contents.height() - _viewport.height();
    _scrollY.pageStep = _viewport.height();
    _scrollY.geometry.moveTo(_viewport.width(), 0);
    _scrollY.geometry.setHeight(_window.height());

    if (_scrollX.value < _scrollX.minimum) {
        _scrollX.value = _scrollX.minimum;
    }
    if (_scrollX.value > _scrollX.maximum) {
        _scrollX.value = _scrollX.maximum;
    }

    if (_scrollY.value < _scrollY.minimum) {
        _scrollY.value = _scrollY.minimum;
    }
    if (_scrollY.value > _scrollY.maximum) {
        _scrollY.value = _scrollY.maximum;
    }

    _viewport.moveTo(0, 0);
    _contents.moveTo(-_scrollX.value, -_scrollY.value);

    _resizeTarget = Region::None;
    return true;
}

/*
If resize target is window
    clamp viewport to window
    clamp contents to viewport if not fixed
    if scrollbar visibility changes, resize viewport
If resize target is viewport
    clamp window to viewport
    clamp contents to viewport if not fixed
    if scrollbar visibility changes, resize window
If resize target is contents
    clamp window and viewport to contents
*/

void MainWindowLayout::clampToWindow()
{
    _viewport.setWidth(_window.width());
    _viewport.setHeight(_window.height());
    _contents.setWidth(_window.width());
    _contents.setHeight(_window.height());

    _scrollX.visible = false;
    _scrollY.visible = false;
}

void MainWindowLayout::clampToViewport()
{
    _window.setWidth(_viewport.width());
    _window.setHeight(_viewport.height());
    _contents.setWidth(_viewport.width());
    _contents.setHeight(_viewport.height());

    _scrollX.visible = false;
    _scrollY.visible = false;
}

void MainWindowLayout::clampToContents()
{
    _viewport.setWidth(_window.width() - _scrollY.geometry.width());
    _viewport.setHeight(_window.height() - _scrollX.geometry.height());

    _scrollX.visible = true;
    _scrollY.visible = true;

    for (int i = 0; i < 2; i++) {
        if (!_scrollY.visible) {
            _viewport.setWidth(_window.width());
        }

        if (_viewport.width() >= _contents.width()) {
            _viewport.setWidth(_contents.width());
            _viewport.setHeight(_window.height());

            _scrollX.visible = false;

            if (_scrollY.visible) {
                _window.setWidth(_viewport.width() + _scrollY.geometry.width());
            } else {
                _window.setWidth(_viewport.width());
            }
        }

        if (!_scrollX.visible) {
            _viewport.setHeight(_window.height());
        }

        if (_viewport.height() >= _contents.height()) {
            _viewport.setHeight(_contents.height());
            _viewport.setWidth(_window.width());

            _scrollY.visible = false;

            if (_scrollX.visible) {
                _window.setHeight(_viewport.height() + _scrollX.geometry.height());
            } else {
                _window.setHeight(_viewport.height());
            }
        }
    }
}
