#include "sequenceinput.h"
#include "filesequence.h"
#include "sequenceutil.h"

#include <algorithm>

#include <QJsonArray>

SequenceInput::SequenceInput(FileSequence& ref) :
    _ref(ref)
{}

bool SequenceInput::isSequence()
{
    for (SequenceMap& map : _frameMap) {
        if (map.isSequence()) return true;
    }
    return false;
}

QString SequenceInput::name()
{
    return isSequence() ? sequenceName() : fileName();
}

QString SequenceInput::fileName()
{
    return frame(startFrame()).fileName();
}

QString SequenceInput::baseName()
{
    using Util = SequenceUtil;

    QString fileName = isSequence() ?
        this->fileName() :
        frame(startFrame()).fileName();

    return Util::parse(fileName).sequenceName;
}

QString SequenceInput::sequenceName()
{
    return baseName();
}

QString SequenceInput::displayName()
{
    if (!isSequence()) return fileName();

    return QString("%1.[%2].ass").arg(
        sequenceName(),
        QString::number(endFrame() + 1));
}

int SequenceInput::startFrame()
{
    int startFrame = 0;
    for (SequenceMap& map : _frameMap) {
        startFrame = std::min(startFrame, map.startFrame());
    }
    return startFrame;
}

int SequenceInput::endFrame()
{
    int endFrame = 0;
    for (SequenceMap& map : _frameMap) {
        endFrame = std::max(endFrame, map.endFrame());
    }
    return endFrame;
}

int SequenceInput::numFrames()
{
    int numFrames = 0;
    int n = endFrame();
    for (int frameNum = startFrame(); frameNum <= n; frameNum++) {
        numFrames += hasFrame(frameNum);
    }
    return numFrames;
}

int SequenceInput::numFramesSkipped()
{
    return (endFrame() - startFrame() + 1) - numFrames();
}

bool SequenceInput::hasFrame(int frameNum)
{
    return frame(frameNum).hasFiles();
}

SequenceFrame SequenceInput::frame(int frameNum)
{
    return SequenceFrame(*this, frameNum);
}

QStringList SequenceInput::frameFiles(int frameNum)
{
    return frame(frameNum).fileNames();
}

//void SequenceInput::addParseResult(int fileIndex, ParseResult result)
void SequenceInput::append(int fileIndex, int startFrame, int numFrames)
{
    //int startFrame = result.startFrame;
    //int endFrame = result.endFrame;
    //int numFrames = result.numFrames;

    if (numFrames == 1) {
        for (SequenceMap& map : _frameMap) {
            if (map.append(startFrame, fileIndex)) return;
        }
    }

    SequenceMap map;
    map.setMaxFile(_ref.numFiles());
    map.setFrameRange(startFrame, numFrames);
    map.setFileRange(fileIndex, 1);
    _frameMap.append(map);
}

QJsonObject SequenceInput::debugJson()
{
    QJsonObject state;

    state["isSequence"] = isSequence();
    state["name"] = name();
    state["fileName"] = fileName();
    state["baseName"] = baseName();
    state["sequenceName"] = sequenceName();
    state["displayName"] = displayName();
    state["startFrame"] = startFrame();
    state["endFrame"] = endFrame();
    state["numFrames"] = numFrames();
    state["numFramesSkipped"] = numFramesSkipped();

    QJsonArray frames;
    QJsonArray frameMap;

    int end = endFrame();
    for (int frameNum = startFrame(); frameNum <= end; frameNum++) {
        if (!hasFrame(frameNum)) continue;

        frames.append(frame(frameNum).debugJson());
    }

    for (SequenceMap& map : _frameMap) {
        frameMap.append(map.debugJson());
    }

    QJsonObject json;

    json["_"] = state;
    json["frames"] = frames;
    json["frameMap"] = frameMap;

    return json;
}
