#include "filesequence.h"
#include "sequenceutil.h"

#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>

using Input = FileSequence::Input;

FileSequence::FileSequence()
{}

FileSequence::~FileSequence()
{
    clearInputs();
}

bool FileSequence::isSequence()
{
    return numFrames() > 1;
}

int FileSequence::numFiles()
{
    return _fileNames.size();
}

int FileSequence::numInputs()
{
    return _inputs.size();
}

int FileSequence::numFrames()
{
    int numFrames = 0;
    for (Input* input : _inputs) {
        int end = input->endFrame();
        if (end >= numFrames) {
            numFrames = end + 1;
        }
    }
    return numFrames;
}

QStringList FileSequence::fileNames()
{
    QStringList fileNames;

    int n = numFiles();
    for (int i = 0; i < n; i++) {
        fileNames.append(fileName(i));
    }

    return fileNames;
}

QStringList FileSequence::displayNames()
{
    QStringList names;

    for (Input* input : _inputs) {
        names.append(input->displayName());
    }

    return names;
}

QString FileSequence::fileName(int i)
{
    if (i < 0 || numFiles() <= i) return QString();

    return SequenceUtil::originalFileName(_fileNames[i]);
}

Input* FileSequence::input(int i)
{
    if (i < 0 || numInputs() <= i) return nullptr;

    return _inputs[i];
}

Input* FileSequence::sequence(QString name)
{
    for (Input* input : _inputs) {
        if (input->sequenceName() == name) {
            return input;
        }
    }
    return nullptr;
}

QStringList FileSequence::frameFiles(int frameNum)
{
    QStringList fileNames;
    for (Input* input : _inputs) {
        fileNames.append(input->frameFiles(frameNum));
    }
    return fileNames;
}

void FileSequence::add(QString fileName)
{
    _fileNames = fileNames();
    _fileNames.append(fileName);
    update();
}

void FileSequence::add(QStringList fileNames)
{
    _fileNames = this->fileNames();
    _fileNames.append(fileNames);
    update();
}

void FileSequence::set(QStringList fileNames)
{
    _fileNames = fileNames;
    update();
}

void FileSequence::removeSequenceName(QString name)
{
    using Util = SequenceUtil;

    name = Util::parse(name).sequenceName;

    /*for (Input* input : _inputs) {
        if (input->sequenceName() == name) {
            _inputs.removeOne(input);
            break;
        }
    }*/

    for (int i = 0; i < _fileNames.size(); i++) {
        QString name2 = Util::parse(_fileNames[i]).sequenceName;
        if (name == name2) {
            _fileNames[i].clear();
        }
    }

    _fileNames.removeAll("");
    update();
}

void FileSequence::clear()
{
    _fileNames.clear();
    update();
}

QString FileSequence::debugString()
{
    QJsonObject state;

    state["isSequence"] = isSequence();
    state["numFiles"] = numFiles();
    state["numInputs"] = numInputs();
    state["numFrames"] = numFrames();

    QJsonArray fileNames = QJsonArray::fromStringList(_fileNames);
    QJsonArray displayNames = QJsonArray::fromStringList(this->displayNames());
    QJsonArray frameFiles;
    QJsonArray inputs;

    int n = numFrames();
    for (int i = 0; i < n; i++) {
        QJsonArray files = QJsonArray::fromStringList(this->frameFiles(i));
        frameFiles.append(files);
    }

    for (Input* input : _inputs) {
        inputs.append(input->debugJson());
    }

    QJsonObject json;

    json["_"] = state;
    json["fileNames"] = fileNames;
    json["displayNames"] = displayNames;
    json["frameFiles"] = frameFiles;
    json["inputs"] = inputs;

    QJsonDocument doc(json);
    return doc.toJson();
}

void FileSequence::clearInputs()
{
    for (Input* input : _inputs) {
        delete input;
    }
    _inputs.clear();
}

void FileSequence::update()
{
    using Util = SequenceUtil;
    using FileInfo = Util::FileInfo;
    using Result = Util::ParseResult;

    clearInputs();

    SequenceUtil::normalize(_fileNames);

    int n = numFiles();
    for (int i = 0; i < n; i++) {
        QString fileName = this->fileName(i);
        FileInfo fileInfo = Util::fileInfo(fileName);
        if (!fileInfo.isValid()) continue;

        Result parseResult = Util::parse(fileInfo.filePath);
        QString sequenceName = parseResult.sequenceName;
        if (sequenceName.isEmpty()) continue;

        int startFrame = parseResult.startFrame - 1;
        //int endFrame = parseResult.endFrame - 1;
        int numFrames = parseResult.numFrames;

        if (startFrame < 0) {
            startFrame = 0;
        }
        if (numFrames < 0) {
            numFrames = 0;
        }

        Input* input = this->sequence(sequenceName);
        if (input == nullptr) {
            input = new Input(*this);
            _inputs.append(input);
        }

        input->append(i, startFrame, numFrames);
    }
}
